# Real-Time Updates with WebSocket

## Overview
Add WebSocket support so clients see task updates, approvals, and messages instantly without refreshing.

---

## 1. Server: WebSocket Setup

### File: `server/services/websocket.ts` (create new)

```typescript
import { WebSocketServer, WebSocket } from "ws";
import { Server } from "http";
import { parse } from "url";

interface AuthenticatedSocket extends WebSocket {
  userId?: string;
  householdId?: string;
  isAlive?: boolean;
}

interface BroadcastMessage {
  type: string;
  payload: any;
  householdId: string;
  excludeUserId?: string;
}

class WebSocketManager {
  private wss: WebSocketServer | null = null;
  private clients: Map<string, Set<AuthenticatedSocket>> = new Map(); // householdId -> sockets
  private userSockets: Map<string, Set<AuthenticatedSocket>> = new Map(); // userId -> sockets

  initialize(server: Server) {
    this.wss = new WebSocketServer({ server, path: "/ws" });

    this.wss.on("connection", (ws: AuthenticatedSocket, req) => {
      const { query } = parse(req.url || "", true);
      const token = query.token as string;
      
      // Validate token and extract user info
      // In production, verify JWT or session token
      this.authenticateSocket(ws, token);

      ws.isAlive = true;

      ws.on("pong", () => {
        ws.isAlive = true;
      });

      ws.on("message", (data) => {
        try {
          const message = JSON.parse(data.toString());
          this.handleMessage(ws, message);
        } catch (e) {
          console.error("WebSocket message parse error:", e);
        }
      });

      ws.on("close", () => {
        this.removeClient(ws);
      });

      ws.on("error", (error) => {
        console.error("WebSocket error:", error);
        this.removeClient(ws);
      });
    });

    // Heartbeat to detect dead connections
    const interval = setInterval(() => {
      this.wss?.clients.forEach((ws: AuthenticatedSocket) => {
        if (ws.isAlive === false) {
          this.removeClient(ws);
          return ws.terminate();
        }
        ws.isAlive = false;
        ws.ping();
      });
    }, 30000);

    this.wss.on("close", () => {
      clearInterval(interval);
    });

    console.log("WebSocket server initialized");
  }

  private async authenticateSocket(ws: AuthenticatedSocket, token: string) {
    try {
      // TODO: Implement proper token verification
      // For now, token format: "userId:householdId"
      // In production, use JWT verification
      const [userId, householdId] = token.split(":");
      
      if (!userId || !householdId) {
        ws.close(4001, "Invalid authentication");
        return;
      }

      ws.userId = userId;
      ws.householdId = householdId;

      // Add to household clients
      if (!this.clients.has(householdId)) {
        this.clients.set(householdId, new Set());
      }
      this.clients.get(householdId)!.add(ws);

      // Add to user sockets
      if (!this.userSockets.has(userId)) {
        this.userSockets.set(userId, new Set());
      }
      this.userSockets.get(userId)!.add(ws);

      // Send connection confirmation
      ws.send(JSON.stringify({
        type: "connected",
        payload: { userId, householdId }
      }));

    } catch (error) {
      console.error("Socket authentication error:", error);
      ws.close(4001, "Authentication failed");
    }
  }

  private removeClient(ws: AuthenticatedSocket) {
    if (ws.householdId) {
      this.clients.get(ws.householdId)?.delete(ws);
    }
    if (ws.userId) {
      this.userSockets.get(ws.userId)?.delete(ws);
    }
  }

  private handleMessage(ws: AuthenticatedSocket, message: any) {
    switch (message.type) {
      case "ping":
        ws.send(JSON.stringify({ type: "pong" }));
        break;
      case "subscribe":
        // Handle subscription to specific channels
        break;
      default:
        console.log("Unknown message type:", message.type);
    }
  }

  /**
   * Broadcast to all clients in a household
   */
  broadcastToHousehold(message: BroadcastMessage) {
    const clients = this.clients.get(message.householdId);
    if (!clients) return;

    const data = JSON.stringify({
      type: message.type,
      payload: message.payload,
      timestamp: new Date().toISOString()
    });

    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        if (message.excludeUserId && client.userId === message.excludeUserId) {
          return; // Don't send to the user who triggered the action
        }
        client.send(data);
      }
    });
  }

  /**
   * Send to a specific user (all their connected devices)
   */
  sendToUser(userId: string, type: string, payload: any) {
    const sockets = this.userSockets.get(userId);
    if (!sockets) return;

    const data = JSON.stringify({
      type,
      payload,
      timestamp: new Date().toISOString()
    });

    sockets.forEach((socket) => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(data);
      }
    });
  }

  /**
   * Get count of connected clients for a household
   */
  getHouseholdConnectionCount(householdId: string): number {
    return this.clients.get(householdId)?.size || 0;
  }
}

// Singleton instance
export const wsManager = new WebSocketManager();

// Helper functions for common broadcasts
export function broadcastTaskUpdate(householdId: string, task: any, action: "created" | "updated" | "deleted", byUserId?: string) {
  wsManager.broadcastToHousehold({
    type: "task:update",
    payload: { task, action },
    householdId,
    excludeUserId: byUserId
  });
}

export function broadcastApprovalUpdate(householdId: string, approval: any, action: "created" | "updated", byUserId?: string) {
  wsManager.broadcastToHousehold({
    type: "approval:update",
    payload: { approval, action },
    householdId,
    excludeUserId: byUserId
  });
}

export function broadcastNewUpdate(householdId: string, update: any, byUserId?: string) {
  wsManager.broadcastToHousehold({
    type: "update:new",
    payload: { update },
    householdId,
    excludeUserId: byUserId
  });
}

export function broadcastNewMessage(householdId: string, message: any, byUserId?: string) {
  wsManager.broadcastToHousehold({
    type: "message:new",
    payload: { message },
    householdId,
    excludeUserId: byUserId
  });
}

export function notifyUser(userId: string, notification: any) {
  wsManager.sendToUser(userId, "notification", notification);
}
```

---

## 2. Server: Initialize WebSocket in Server Setup

### File: `server/index.ts` - Add after HTTP server creation:

```typescript
import { wsManager } from "./services/websocket";

// After: const server = createServer(app);
wsManager.initialize(server);
```

---

## 3. Server: Add Broadcasts to Routes

### File: `server/routes.ts` - Add imports:

```typescript
import { 
  broadcastTaskUpdate, 
  broadcastApprovalUpdate, 
  broadcastNewUpdate,
  broadcastNewMessage,
  notifyUser 
} from "./services/websocket";
```

### Update task creation endpoint:

```typescript
app.post("/api/tasks", isAuthenticated, householdContext, async (req: any, res) => {
  try {
    const userId = req.user.claims.sub;
    const householdId = req.householdId!;
    
    const taskData = {
      ...req.body,
      createdBy: userId,
      householdId,
      dueAt: req.body.dueAt ? new Date(req.body.dueAt) : null,
    };
    
    const task = await storage.createTask(taskData);
    
    // Broadcast to household
    broadcastTaskUpdate(householdId, task, "created", userId);
    
    res.status(201).json(task);
  } catch (error) {
    console.error("Error creating task:", error);
    res.status(500).json({ message: "Failed to create task" });
  }
});
```

### Update task update endpoint:

```typescript
app.patch("/api/tasks/:id", isAuthenticated, householdContext, async (req: any, res) => {
  try {
    const userId = req.user.claims.sub;
    const householdId = req.householdId!;
    
    const updateData = {
      ...req.body,
      ...(req.body.dueAt !== undefined && { dueAt: req.body.dueAt ? new Date(req.body.dueAt) : null }),
    };
    
    const task = await storage.updateTask(req.params.id, updateData);
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }
    
    // Broadcast to household
    broadcastTaskUpdate(householdId, task, "updated", userId);
    
    res.json(task);
  } catch (error) {
    console.error("Error updating task:", error);
    res.status(500).json({ message: "Failed to update task" });
  }
});
```

---

## 4. Client: WebSocket Hook

### File: `client/src/hooks/use-websocket.ts` (create new)

```typescript
import { useEffect, useRef, useCallback, useState } from "react";
import { useUser } from "@/lib/user-context";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type MessageHandler = (payload: any) => void;

interface WebSocketMessage {
  type: string;
  payload: any;
  timestamp: string;
}

export function useWebSocket() {
  const { userProfile } = useUser();
  const { toast } = useToast();
  const wsRef = useRef<WebSocket | null>(null);
  const handlersRef = useRef<Map<string, Set<MessageHandler>>>(new Map());
  const [isConnected, setIsConnected] = useState(false);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  const connect = useCallback(() => {
    if (!userProfile?.userId || !userProfile?.householdId) return;
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const token = `${userProfile.userId}:${userProfile.householdId}`;
    const wsUrl = `${protocol}//${window.location.host}/ws?token=${encodeURIComponent(token)}`;

    try {
      wsRef.current = new WebSocket(wsUrl);

      wsRef.current.onopen = () => {
        console.log("WebSocket connected");
        setIsConnected(true);
        reconnectAttempts.current = 0;
      };

      wsRef.current.onclose = (event) => {
        console.log("WebSocket disconnected:", event.code, event.reason);
        setIsConnected(false);
        
        // Attempt reconnection with exponential backoff
        if (reconnectAttempts.current < maxReconnectAttempts) {
          const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectAttempts.current++;
            connect();
          }, delay);
        }
      };

      wsRef.current.onerror = (error) => {
        console.error("WebSocket error:", error);
      };

      wsRef.current.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          handleMessage(message);
        } catch (e) {
          console.error("Failed to parse WebSocket message:", e);
        }
      };
    } catch (error) {
      console.error("Failed to create WebSocket:", error);
    }
  }, [userProfile?.userId, userProfile?.householdId]);

  const handleMessage = useCallback((message: WebSocketMessage) => {
    const { type, payload } = message;

    // Handle built-in message types with query invalidation
    switch (type) {
      case "task:update":
        queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
        queryClient.invalidateQueries({ queryKey: ["/api/today"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
        if (payload.action === "created") {
          toast({ description: "New task added" });
        }
        break;

      case "approval:update":
        queryClient.invalidateQueries({ queryKey: ["/api/approvals"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
        if (payload.action === "created") {
          toast({ description: "New approval request" });
        }
        break;

      case "update:new":
        queryClient.invalidateQueries({ queryKey: ["/api/updates"] });
        queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
        toast({ description: "New update posted" });
        break;

      case "message:new":
        queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
        queryClient.invalidateQueries({ queryKey: ["/api/messages/unread-count"] });
        toast({ description: "New message" });
        break;

      case "notification":
        queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
        if (payload.title) {
          toast({ title: payload.title, description: payload.body });
        }
        break;

      case "spending:update":
        queryClient.invalidateQueries({ queryKey: ["/api/spending"] });
        queryClient.invalidateQueries({ queryKey: ["/api/invoices/pending"] });
        break;
    }

    // Call custom handlers
    const handlers = handlersRef.current.get(type);
    if (handlers) {
      handlers.forEach((handler) => handler(payload));
    }
  }, [toast]);

  const subscribe = useCallback((type: string, handler: MessageHandler) => {
    if (!handlersRef.current.has(type)) {
      handlersRef.current.set(type, new Set());
    }
    handlersRef.current.get(type)!.add(handler);

    // Return unsubscribe function
    return () => {
      handlersRef.current.get(type)?.delete(handler);
    };
  }, []);

  const send = useCallback((type: string, payload: any) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type, payload }));
    }
  }, []);

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  return {
    isConnected,
    subscribe,
    send,
    reconnect: connect
  };
}
```

---

## 5. Client: Add WebSocket Provider

### File: `client/src/lib/websocket-context.tsx` (create new)

```typescript
import { createContext, useContext, ReactNode } from "react";
import { useWebSocket } from "@/hooks/use-websocket";

interface WebSocketContextType {
  isConnected: boolean;
  subscribe: (type: string, handler: (payload: any) => void) => () => void;
  send: (type: string, payload: any) => void;
  reconnect: () => void;
}

const WebSocketContext = createContext<WebSocketContextType | null>(null);

export function WebSocketProvider({ children }: { children: ReactNode }) {
  const ws = useWebSocket();

  return (
    <WebSocketContext.Provider value={ws}>
      {children}
    </WebSocketContext.Provider>
  );
}

export function useWS() {
  const context = useContext(WebSocketContext);
  if (!context) {
    throw new Error("useWS must be used within WebSocketProvider");
  }
  return context;
}
```

### Update App.tsx to include provider:

```typescript
// In AuthenticatedApp component, wrap with WebSocketProvider
import { WebSocketProvider } from "@/lib/websocket-context";

function AuthenticatedApp() {
  // ... existing code ...

  return (
    <WebSocketProvider>
      {/* existing content */}
    </WebSocketProvider>
  );
}
```

---

## 6. Client: Connection Status Indicator

### File: `client/src/components/connection-status.tsx` (create new)

```typescript
import { useWS } from "@/lib/websocket-context";
import { Wifi, WifiOff } from "lucide-react";
import { cn } from "@/lib/utils";

export function ConnectionStatus() {
  const { isConnected } = useWS();

  return (
    <div className={cn(
      "fixed bottom-20 right-4 z-50 flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-300",
      isConnected 
        ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 opacity-0 hover:opacity-100"
        : "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 animate-pulse"
    )}>
      {isConnected ? (
        <>
          <Wifi className="h-3 w-3" />
          Connected
        </>
      ) : (
        <>
          <WifiOff className="h-3 w-3" />
          Reconnecting...
        </>
      )}
    </div>
  );
}
```

---

## Testing

1. Open app in two browser windows
2. Create a task in one window
3. Second window should show toast "New task added" and refresh task list automatically
4. Check Network tab for WebSocket connection to `/ws`
