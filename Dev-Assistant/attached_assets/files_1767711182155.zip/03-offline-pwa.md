# Offline Support & PWA Enhancement

## Overview
Add service worker for offline capability, background sync for queued actions, and proper PWA manifest.

---

## 1. Service Worker with Workbox

### File: `client/src/sw.ts` (create new)

```typescript
/// <reference lib="webworker" />

import { precacheAndRoute, cleanupOutdatedCaches } from "workbox-precaching";
import { registerRoute, NavigationRoute, Route } from "workbox-routing";
import { 
  NetworkFirst, 
  CacheFirst, 
  StaleWhileRevalidate 
} from "workbox-strategies";
import { ExpirationPlugin } from "workbox-expiration";
import { BackgroundSyncPlugin } from "workbox-background-sync";
import { CacheableResponsePlugin } from "workbox-cacheable-response";

declare let self: ServiceWorkerGlobalScope;

// Precache static assets
precacheAndRoute(self.__WB_MANIFEST);
cleanupOutdatedCaches();

// Cache API responses with NetworkFirst (try network, fall back to cache)
const apiStrategy = new NetworkFirst({
  cacheName: "api-cache",
  plugins: [
    new CacheableResponsePlugin({ statuses: [0, 200] }),
    new ExpirationPlugin({
      maxEntries: 100,
      maxAgeSeconds: 60 * 60 * 24, // 24 hours
    }),
  ],
});

// Cache GET API requests
registerRoute(
  ({ url }) => url.pathname.startsWith("/api/") && !url.pathname.includes("/ai/"),
  apiStrategy
);

// Cache images with CacheFirst
registerRoute(
  ({ request }) => request.destination === "image",
  new CacheFirst({
    cacheName: "images",
    plugins: [
      new CacheableResponsePlugin({ statuses: [0, 200] }),
      new ExpirationPlugin({
        maxEntries: 50,
        maxAgeSeconds: 60 * 60 * 24 * 30, // 30 days
      }),
    ],
  })
);

// Cache fonts with CacheFirst
registerRoute(
  ({ request }) => request.destination === "font",
  new CacheFirst({
    cacheName: "fonts",
    plugins: [
      new ExpirationPlugin({
        maxEntries: 10,
        maxAgeSeconds: 60 * 60 * 24 * 365, // 1 year
      }),
    ],
  })
);

// Background sync for POST/PATCH/DELETE requests when offline
const bgSyncPlugin = new BackgroundSyncPlugin("hndld-sync-queue", {
  maxRetentionTime: 24 * 60, // Retry for up to 24 hours
  onSync: async ({ queue }) => {
    let entry;
    while ((entry = await queue.shiftRequest())) {
      try {
        await fetch(entry.request.clone());
        console.log("Background sync successful for:", entry.request.url);
      } catch (error) {
        console.error("Background sync failed:", error);
        await queue.unshiftRequest(entry);
        throw error;
      }
    }
  },
});

// Queue mutations when offline
registerRoute(
  ({ url, request }) => 
    url.pathname.startsWith("/api/") && 
    ["POST", "PATCH", "PUT", "DELETE"].includes(request.method),
  new NetworkFirst({
    cacheName: "api-mutations",
    plugins: [bgSyncPlugin],
  }),
  "POST"
);

registerRoute(
  ({ url, request }) => 
    url.pathname.startsWith("/api/") && 
    ["POST", "PATCH", "PUT", "DELETE"].includes(request.method),
  new NetworkFirst({
    cacheName: "api-mutations",
    plugins: [bgSyncPlugin],
  }),
  "PATCH"
);

registerRoute(
  ({ url, request }) => 
    url.pathname.startsWith("/api/") && 
    ["POST", "PATCH", "PUT", "DELETE"].includes(request.method),
  new NetworkFirst({
    cacheName: "api-mutations",
    plugins: [bgSyncPlugin],
  }),
  "PUT"
);

registerRoute(
  ({ url, request }) => 
    url.pathname.startsWith("/api/") && 
    ["POST", "PATCH", "PUT", "DELETE"].includes(request.method),
  new NetworkFirst({
    cacheName: "api-mutations",
    plugins: [bgSyncPlugin],
  }),
  "DELETE"
);

// Handle navigation requests (SPA)
registerRoute(
  new NavigationRoute(
    new NetworkFirst({
      cacheName: "pages",
      plugins: [
        new CacheableResponsePlugin({ statuses: [0, 200] }),
      ],
    }),
    {
      // Don't cache auth-related paths
      denylist: [/\/api\//, /\/auth\//],
    }
  )
);

// Listen for skip waiting message
self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});

// Notify clients when back online and sync complete
self.addEventListener("sync", (event) => {
  if (event.tag === "hndld-sync-queue") {
    event.waitUntil(
      (async () => {
        const clients = await self.clients.matchAll();
        clients.forEach((client) => {
          client.postMessage({
            type: "SYNC_COMPLETE",
            timestamp: Date.now(),
          });
        });
      })()
    );
  }
});
```

---

## 2. Vite Config for Service Worker

### File: `vite.config.ts` - Update:

```typescript
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { VitePWA } from "vite-plugin-pwa";
import path from "path";

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      strategies: "injectManifest",
      srcDir: "src",
      filename: "sw.ts",
      registerType: "prompt",
      injectRegister: false,
      manifest: {
        name: "hndld - Home Concierge",
        short_name: "hndld",
        description: "Luxury home concierge for busy families",
        theme_color: "#1D2A44",
        background_color: "#F6F2EA",
        display: "standalone",
        orientation: "portrait",
        start_url: "/",
        scope: "/",
        icons: [
          {
            src: "/icons/icon-192.png",
            sizes: "192x192",
            type: "image/png",
          },
          {
            src: "/icons/icon-512.png",
            sizes: "512x512",
            type: "image/png",
          },
          {
            src: "/icons/icon-512-maskable.png",
            sizes: "512x512",
            type: "image/png",
            purpose: "maskable",
          },
        ],
        categories: ["lifestyle", "productivity"],
      },
      injectManifest: {
        globPatterns: ["**/*.{js,css,html,ico,png,svg,woff2}"],
      },
      devOptions: {
        enabled: true,
        type: "module",
      },
    }),
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./client/src"),
      "@shared": path.resolve(__dirname, "./shared"),
    },
  },
});
```

---

## 3. Install Dependencies

```bash
npm install vite-plugin-pwa workbox-precaching workbox-routing workbox-strategies workbox-expiration workbox-background-sync workbox-cacheable-response
```

---

## 4. Service Worker Registration

### File: `client/src/lib/sw-registration.ts` (create new)

```typescript
import { registerSW } from "virtual:pwa-register";

export function registerServiceWorker() {
  const updateSW = registerSW({
    onNeedRefresh() {
      // Show update notification
      const shouldUpdate = window.confirm(
        "A new version of hndld is available. Reload to update?"
      );
      if (shouldUpdate) {
        updateSW(true);
      }
    },
    onOfflineReady() {
      console.log("hndld is ready to work offline");
    },
    onRegistered(registration) {
      console.log("Service worker registered:", registration);
      
      // Check for updates every hour
      setInterval(() => {
        registration?.update();
      }, 60 * 60 * 1000);
    },
    onRegisterError(error) {
      console.error("Service worker registration failed:", error);
    },
  });

  // Listen for sync complete messages from SW
  navigator.serviceWorker?.addEventListener("message", (event) => {
    if (event.data?.type === "SYNC_COMPLETE") {
      // Invalidate queries to refresh data
      window.dispatchEvent(new CustomEvent("sw-sync-complete"));
    }
  });
}
```

### Update `client/src/main.tsx`:

```typescript
import { registerServiceWorker } from "./lib/sw-registration";

// At the end of the file
if ("serviceWorker" in navigator) {
  registerServiceWorker();
}
```

---

## 5. Offline Status Hook

### File: `client/src/hooks/use-online-status.ts` (create new)

```typescript
import { useState, useEffect } from "react";

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [wasOffline, setWasOffline] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      if (wasOffline) {
        // Trigger data refresh after coming back online
        window.dispatchEvent(new CustomEvent("network-restored"));
      }
    };

    const handleOffline = () => {
      setIsOnline(false);
      setWasOffline(true);
    };

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, [wasOffline]);

  return { isOnline, wasOffline };
}
```

---

## 6. Offline Banner Component

### File: `client/src/components/offline-banner.tsx` (create new)

```typescript
import { useOnlineStatus } from "@/hooks/use-online-status";
import { WifiOff, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function OfflineBanner() {
  const { isOnline } = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className={cn(
      "fixed top-14 left-0 right-0 z-50",
      "bg-amber-500 text-white px-4 py-2",
      "flex items-center justify-center gap-2 text-sm font-medium",
      "animate-in slide-in-from-top duration-300"
    )}>
      <WifiOff className="h-4 w-4" />
      <span>You're offline. Changes will sync when connected.</span>
    </div>
  );
}
```

### Add to `AppLayout`:

```typescript
import { OfflineBanner } from "@/components/offline-banner";

export function AppLayout({ children }: AppLayoutProps) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      <OfflineBanner />
      <main 
        className="flex-1 overflow-y-auto"
        style={{ paddingBottom: "calc(var(--hndld-bottom-pad, 5.5rem) + env(safe-area-inset-bottom))" }}
      >
        {children}
      </main>
      <BottomNav />
    </div>
  );
}
```

---

## 7. Optimistic Updates Pattern

Update mutations to work optimistically for better offline UX.

### File: `client/src/lib/optimistic-mutations.ts` (create new)

```typescript
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "./queryClient";
import { useToast } from "@/hooks/use-toast";

interface OptimisticMutationOptions<TData, TVariables> {
  mutationFn: (variables: TVariables) => Promise<TData>;
  queryKey: string[];
  optimisticUpdate?: (old: any, variables: TVariables) => any;
  onSuccess?: (data: TData, variables: TVariables) => void;
  onError?: (error: Error, variables: TVariables) => void;
  successMessage?: string;
  errorMessage?: string;
}

export function useOptimisticMutation<TData, TVariables>({
  mutationFn,
  queryKey,
  optimisticUpdate,
  onSuccess,
  onError,
  successMessage,
  errorMessage,
}: OptimisticMutationOptions<TData, TVariables>) {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn,
    onMutate: async (variables) => {
      // Cancel any outgoing refetches
      await queryClient.cancelQueries({ queryKey });

      // Snapshot previous value
      const previousData = queryClient.getQueryData(queryKey);

      // Optimistically update
      if (optimisticUpdate) {
        queryClient.setQueryData(queryKey, (old: any) => 
          optimisticUpdate(old, variables)
        );
      }

      return { previousData };
    },
    onSuccess: (data, variables) => {
      if (successMessage) {
        toast({ description: successMessage });
      }
      onSuccess?.(data, variables);
    },
    onError: (error: Error, variables, context) => {
      // Rollback on error
      if (context?.previousData) {
        queryClient.setQueryData(queryKey, context.previousData);
      }
      
      toast({
        variant: "destructive",
        description: errorMessage || error.message || "Something went wrong",
      });
      
      onError?.(error, variables);
    },
    onSettled: () => {
      // Always refetch after error or success
      queryClient.invalidateQueries({ queryKey });
    },
  });
}

// Example usage for task completion
export function useCompleteTaskOptimistic() {
  return useOptimisticMutation({
    mutationFn: async (taskId: string) => {
      const response = await apiRequest("POST", `/api/tasks/${taskId}/complete`, {});
      return response.json();
    },
    queryKey: ["/api/tasks"],
    optimisticUpdate: (old, taskId) => {
      if (!old) return old;
      return old.map((task: any) =>
        task.id === taskId ? { ...task, status: "DONE" } : task
      );
    },
    successMessage: "Task completed",
  });
}
```

---

## 8. Sync Queue Status Component

Show pending offline actions.

### File: `client/src/components/sync-status.tsx` (create new)

```typescript
import { useState, useEffect } from "react";
import { Cloud, CloudOff, RefreshCw, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useOnlineStatus } from "@/hooks/use-online-status";
import { cn } from "@/lib/utils";

export function SyncStatus() {
  const { isOnline } = useOnlineStatus();
  const [pendingCount, setPendingCount] = useState(0);
  const [lastSynced, setLastSynced] = useState<Date | null>(null);

  useEffect(() => {
    // Listen for sync complete events from service worker
    const handleSyncComplete = () => {
      setPendingCount(0);
      setLastSynced(new Date());
    };

    window.addEventListener("sw-sync-complete", handleSyncComplete);
    
    return () => {
      window.removeEventListener("sw-sync-complete", handleSyncComplete);
    };
  }, []);

  // Check IndexedDB for pending requests (simplified)
  useEffect(() => {
    const checkPending = async () => {
      if ("indexedDB" in window) {
        try {
          // This would check workbox's background sync queue
          // Simplified for demo
        } catch (e) {
          console.error("Error checking pending sync:", e);
        }
      }
    };

    const interval = setInterval(checkPending, 5000);
    checkPending();

    return () => clearInterval(interval);
  }, []);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          {isOnline ? (
            pendingCount > 0 ? (
              <RefreshCw className="h-5 w-5 animate-spin" />
            ) : (
              <Cloud className="h-5 w-5 text-emerald-500" />
            )
          ) : (
            <CloudOff className="h-5 w-5 text-amber-500" />
          )}
          {pendingCount > 0 && (
            <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-amber-500 text-[10px] text-white flex items-center justify-center">
              {pendingCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-64">
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            {isOnline ? (
              <>
                <div className="h-2 w-2 rounded-full bg-emerald-500" />
                <span className="text-sm font-medium">Connected</span>
              </>
            ) : (
              <>
                <div className="h-2 w-2 rounded-full bg-amber-500 animate-pulse" />
                <span className="text-sm font-medium">Offline</span>
              </>
            )}
          </div>

          {pendingCount > 0 && (
            <div className="text-sm text-muted-foreground">
              {pendingCount} change{pendingCount !== 1 ? "s" : ""} waiting to sync
            </div>
          )}

          {lastSynced && (
            <div className="text-xs text-muted-foreground">
              Last synced: {lastSynced.toLocaleTimeString()}
            </div>
          )}

          {!isOnline && (
            <p className="text-xs text-muted-foreground">
              Your changes are saved locally and will sync when you're back online.
            </p>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
```

---

## Summary: Offline Capabilities

| Feature | Implementation |
|---------|---------------|
| **Static Asset Caching** | Workbox precache for JS/CSS/HTML |
| **API Response Caching** | NetworkFirst with 24hr expiration |
| **Background Sync** | Queue mutations when offline, replay on reconnect |
| **Offline Indicator** | Banner when disconnected |
| **Optimistic Updates** | Immediate UI feedback before server confirms |
| **Sync Status** | Show pending changes count |

After implementing, test by:
1. Load app while online
2. Toggle network off in DevTools
3. Try creating a task
4. Toggle network back on
5. Verify task syncs automatically
