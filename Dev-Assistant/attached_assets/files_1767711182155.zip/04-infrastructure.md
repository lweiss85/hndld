# Infrastructure Improvements

## 1. Soft Delete Pattern

### File: `shared/schema.ts` - Add to relevant tables:

```typescript
// Add these fields to tasks, approvals, updates, requests, etc.
deletedAt: timestamp("deleted_at"),
deletedBy: varchar("deleted_by"),

// Example for tasks table:
export const tasks = pgTable("tasks", {
  // ... existing fields ...
  
  // Soft delete
  deletedAt: timestamp("deleted_at"),
  deletedBy: varchar("deleted_by"),
}, (table) => [
  // ... existing indexes ...
  index("tasks_deleted_at_idx").on(table.deletedAt),
]);
```

### File: `server/storage.ts` - Update queries to filter soft-deleted:

```typescript
// Update getTasks to exclude soft-deleted
async getTasks(householdId: string, includeDeleted = false): Promise<Task[]> {
  let query = db
    .select()
    .from(tasks)
    .where(eq(tasks.householdId, householdId));
  
  if (!includeDeleted) {
    query = query.where(isNull(tasks.deletedAt));
  }
  
  return query.orderBy(desc(tasks.createdAt));
}

// Update deleteTask to soft delete
async softDeleteTask(taskId: string, deletedBy: string): Promise<void> {
  await db
    .update(tasks)
    .set({ 
      deletedAt: new Date(), 
      deletedBy 
    })
    .where(eq(tasks.id, taskId));
}

// Add restore function
async restoreTask(taskId: string): Promise<Task | null> {
  const [task] = await db
    .update(tasks)
    .set({ 
      deletedAt: null, 
      deletedBy: null 
    })
    .where(eq(tasks.id, taskId))
    .returning();
  return task || null;
}

// Hard delete (admin only, after retention period)
async hardDeleteTask(taskId: string): Promise<void> {
  await db.delete(tasks).where(eq(tasks.id, taskId));
}
```

### File: `server/routes.ts` - Update delete endpoint:

```typescript
app.delete("/api/tasks/:id", isAuthenticated, householdContext, async (req: any, res) => {
  try {
    const userId = req.user.claims.sub;
    
    // Soft delete instead of hard delete
    await storage.softDeleteTask(req.params.id, userId);
    
    // Log the deletion
    await storage.createAuditLog({
      householdId: req.householdId!,
      userId,
      action: "TASK_DELETED",
      entityType: "TASK",
      entityId: req.params.id,
    });
    
    res.status(204).send();
  } catch (error) {
    console.error("Error deleting task:", error);
    res.status(500).json({ message: "Failed to delete task" });
  }
});

// Add restore endpoint
app.post("/api/tasks/:id/restore", isAuthenticated, householdContext, async (req: any, res) => {
  try {
    const task = await storage.restoreTask(req.params.id);
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }
    res.json(task);
  } catch (error) {
    console.error("Error restoring task:", error);
    res.status(500).json({ message: "Failed to restore task" });
  }
});
```

---

## 2. Redis Caching Layer

### Install Redis:

```bash
npm install ioredis
```

### File: `server/services/cache.ts` (create new)

```typescript
import Redis from "ioredis";

const REDIS_URL = process.env.REDIS_URL || "redis://localhost:6379";
const DEFAULT_TTL = 60 * 5; // 5 minutes

class CacheService {
  private redis: Redis | null = null;
  private enabled: boolean = false;

  constructor() {
    if (process.env.REDIS_URL) {
      try {
        this.redis = new Redis(REDIS_URL, {
          maxRetriesPerRequest: 3,
          retryDelayOnFailover: 100,
          lazyConnect: true,
        });

        this.redis.on("connect", () => {
          console.log("Redis connected");
          this.enabled = true;
        });

        this.redis.on("error", (err) => {
          console.error("Redis error:", err);
          this.enabled = false;
        });

        this.redis.connect().catch(console.error);
      } catch (error) {
        console.warn("Redis not available, caching disabled");
      }
    } else {
      console.log("REDIS_URL not set, caching disabled");
    }
  }

  private makeKey(prefix: string, ...parts: string[]): string {
    return `hndld:${prefix}:${parts.join(":")}`;
  }

  async get<T>(key: string): Promise<T | null> {
    if (!this.enabled || !this.redis) return null;
    
    try {
      const data = await this.redis.get(key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error("Cache get error:", error);
      return null;
    }
  }

  async set(key: string, value: any, ttl: number = DEFAULT_TTL): Promise<void> {
    if (!this.enabled || !this.redis) return;
    
    try {
      await this.redis.setex(key, ttl, JSON.stringify(value));
    } catch (error) {
      console.error("Cache set error:", error);
    }
  }

  async del(key: string): Promise<void> {
    if (!this.enabled || !this.redis) return;
    
    try {
      await this.redis.del(key);
    } catch (error) {
      console.error("Cache del error:", error);
    }
  }

  async delPattern(pattern: string): Promise<void> {
    if (!this.enabled || !this.redis) return;
    
    try {
      const keys = await this.redis.keys(pattern);
      if (keys.length > 0) {
        await this.redis.del(...keys);
      }
    } catch (error) {
      console.error("Cache delPattern error:", error);
    }
  }

  // Household-specific cache helpers
  async getHouseholdData<T>(householdId: string, dataType: string): Promise<T | null> {
    return this.get<T>(this.makeKey("household", householdId, dataType));
  }

  async setHouseholdData(householdId: string, dataType: string, data: any, ttl?: number): Promise<void> {
    return this.set(this.makeKey("household", householdId, dataType), data, ttl);
  }

  async invalidateHousehold(householdId: string, dataType?: string): Promise<void> {
    if (dataType) {
      await this.del(this.makeKey("household", householdId, dataType));
    } else {
      await this.delPattern(`hndld:household:${householdId}:*`);
    }
  }

  // User-specific cache helpers
  async getUserData<T>(userId: string, dataType: string): Promise<T | null> {
    return this.get<T>(this.makeKey("user", userId, dataType));
  }

  async setUserData(userId: string, dataType: string, data: any, ttl?: number): Promise<void> {
    return this.set(this.makeKey("user", userId, dataType), data, ttl);
  }

  async invalidateUser(userId: string): Promise<void> {
    await this.delPattern(`hndld:user:${userId}:*`);
  }
}

export const cache = new CacheService();
```

### Usage in routes - wrap expensive queries:

```typescript
import { cache } from "./services/cache";

// Example: Cache household settings
app.get("/api/household/settings", isAuthenticated, householdContext, async (req: any, res) => {
  try {
    const householdId = req.householdId!;
    
    // Try cache first
    const cached = await cache.getHouseholdData(householdId, "settings");
    if (cached) {
      return res.json(cached);
    }
    
    // Fetch from DB
    const settings = await storage.getHouseholdSettings(householdId);
    
    // Cache for 10 minutes
    await cache.setHouseholdData(householdId, "settings", settings, 600);
    
    res.json(settings);
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Failed to fetch settings" });
  }
});

// Invalidate cache when updating
app.put("/api/household/settings", isAuthenticated, householdContext, async (req: any, res) => {
  try {
    const householdId = req.householdId!;
    
    const settings = await storage.updateHouseholdSettings(householdId, req.body);
    
    // Invalidate cache
    await cache.invalidateHousehold(householdId, "settings");
    
    res.json(settings);
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ message: "Failed to update settings" });
  }
});
```

---

## 3. File Upload Security

### File: `server/middleware/file-validation.ts` (create new)

```typescript
import { Request, Response, NextFunction } from "express";
import fileType from "file-type";
import { lookup } from "mime-types";

// Allowed file types
const ALLOWED_TYPES = {
  images: ["image/jpeg", "image/png", "image/gif", "image/webp", "image/heic"],
  documents: ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
  spreadsheets: ["application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/csv"],
};

const ALL_ALLOWED = [
  ...ALLOWED_TYPES.images,
  ...ALLOWED_TYPES.documents,
  ...ALLOWED_TYPES.spreadsheets,
];

// File size limits (in bytes)
const SIZE_LIMITS = {
  image: 10 * 1024 * 1024, // 10MB
  document: 25 * 1024 * 1024, // 25MB
  default: 10 * 1024 * 1024, // 10MB
};

interface FileValidationOptions {
  allowedTypes?: string[];
  maxSize?: number;
  required?: boolean;
}

export function validateFileUpload(options: FileValidationOptions = {}) {
  const {
    allowedTypes = ALL_ALLOWED,
    maxSize = SIZE_LIMITS.default,
    required = true,
  } = options;

  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const file = (req as any).file;

      // Check if file exists
      if (!file) {
        if (required) {
          return res.status(400).json({ message: "No file uploaded" });
        }
        return next();
      }

      // Check file size
      if (file.size > maxSize) {
        return res.status(400).json({
          message: `File too large. Maximum size is ${Math.round(maxSize / 1024 / 1024)}MB`,
        });
      }

      // Verify actual file type (not just extension)
      const buffer = file.buffer;
      const type = await fileType.fromBuffer(buffer);

      if (!type) {
        // For text files that file-type can't detect
        const mimeFromExt = lookup(file.originalname);
        if (mimeFromExt && allowedTypes.includes(mimeFromExt)) {
          (req as any).validatedMimeType = mimeFromExt;
          return next();
        }
        return res.status(400).json({ message: "Could not determine file type" });
      }

      if (!allowedTypes.includes(type.mime)) {
        return res.status(400).json({
          message: `File type not allowed. Allowed types: ${allowedTypes.join(", ")}`,
        });
      }

      // Attach validated type to request
      (req as any).validatedMimeType = type.mime;

      next();
    } catch (error) {
      console.error("File validation error:", error);
      res.status(500).json({ message: "File validation failed" });
    }
  };
}

// Image-specific validation with dimension checks
export function validateImageUpload(options: {
  maxWidth?: number;
  maxHeight?: number;
  maxSize?: number;
} = {}) {
  const { maxWidth = 4096, maxHeight = 4096, maxSize = SIZE_LIMITS.image } = options;

  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const file = (req as any).file;
      if (!file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // First run type validation
      const typeMiddleware = validateFileUpload({
        allowedTypes: ALLOWED_TYPES.images,
        maxSize,
      });

      await new Promise<void>((resolve, reject) => {
        typeMiddleware(req, res, (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      // Check image dimensions using sharp
      const sharp = await import("sharp");
      const metadata = await sharp.default(file.buffer).metadata();

      if (metadata.width && metadata.width > maxWidth) {
        return res.status(400).json({
          message: `Image width exceeds maximum of ${maxWidth}px`,
        });
      }

      if (metadata.height && metadata.height > maxHeight) {
        return res.status(400).json({
          message: `Image height exceeds maximum of ${maxHeight}px`,
        });
      }

      // Attach metadata
      (req as any).imageMetadata = metadata;

      next();
    } catch (error) {
      console.error("Image validation error:", error);
      res.status(500).json({ message: "Image validation failed" });
    }
  };
}
```

### Update file upload route:

```typescript
import { validateFileUpload, validateImageUpload } from "./middleware/file-validation";
import multer from "multer";

// Configure multer for memory storage
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 25 * 1024 * 1024, // 25MB absolute max
  },
});

// Protected file upload endpoint
app.post(
  "/api/files/upload",
  isAuthenticated,
  householdContext,
  upload.single("file"),
  validateFileUpload(),
  async (req: any, res) => {
    try {
      const file = req.file;
      const validatedType = req.validatedMimeType;
      
      // Process and store file...
      // Use validatedType instead of file.mimetype for safety
      
      res.json({ success: true });
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ message: "Upload failed" });
    }
  }
);
```

---

## 4. Centralized Error Handling with Sentry

### Install Sentry:

```bash
npm install @sentry/node @sentry/profiling-node
```

### File: `server/lib/error-handler.ts` (create new)

```typescript
import * as Sentry from "@sentry/node";
import { ProfilingIntegration } from "@sentry/profiling-node";
import { Express, Request, Response, NextFunction } from "express";

export function initializeSentry(app: Express) {
  if (!process.env.SENTRY_DSN) {
    console.warn("SENTRY_DSN not set, error tracking disabled");
    return;
  }

  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    environment: process.env.NODE_ENV || "development",
    integrations: [
      new Sentry.Integrations.Http({ tracing: true }),
      new Sentry.Integrations.Express({ app }),
      new ProfilingIntegration(),
    ],
    tracesSampleRate: process.env.NODE_ENV === "production" ? 0.1 : 1.0,
    profilesSampleRate: 0.1,
  });

  // Request handler (must be first)
  app.use(Sentry.Handlers.requestHandler());
  
  // Tracing handler
  app.use(Sentry.Handlers.tracingHandler());
}

export function setupErrorHandlers(app: Express) {
  // Sentry error handler (must be before other error handlers)
  if (process.env.SENTRY_DSN) {
    app.use(Sentry.Handlers.errorHandler());
  }

  // Custom error handler
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    console.error("Unhandled error:", err);

    // Don't leak error details in production
    const isDev = process.env.NODE_ENV !== "production";

    res.status(err.status || 500).json({
      message: isDev ? err.message : "An unexpected error occurred",
      ...(isDev && { stack: err.stack }),
    });
  });
}

// Helper to capture errors with context
export function captureError(error: Error, context?: Record<string, any>) {
  if (process.env.SENTRY_DSN) {
    Sentry.withScope((scope) => {
      if (context) {
        Object.entries(context).forEach(([key, value]) => {
          scope.setExtra(key, value);
        });
      }
      Sentry.captureException(error);
    });
  }
  console.error("Error:", error, context);
}

// Helper to track user context
export function setUserContext(userId: string, email?: string, role?: string) {
  Sentry.setUser({
    id: userId,
    email,
    role,
  });
}
```

### Update `server/index.ts`:

```typescript
import { initializeSentry, setupErrorHandlers } from "./lib/error-handler";

const app = express();

// Initialize Sentry first
initializeSentry(app);

// ... your routes ...

// Setup error handlers last
setupErrorHandlers(app);
```

---

## 5. API Rate Limiting Improvements

### File: `server/lib/rate-limit.ts` - Enhanced version:

```typescript
import rateLimit from "express-rate-limit";
import RedisStore from "rate-limit-redis";
import { cache } from "../services/cache";

// Create store based on Redis availability
function createStore(prefix: string) {
  if (process.env.REDIS_URL) {
    return new RedisStore({
      // @ts-ignore - types mismatch
      sendCommand: (...args: string[]) => cache.redis?.call(...args),
      prefix: `ratelimit:${prefix}:`,
    });
  }
  return undefined; // Use memory store
}

// Standard API rate limit
export const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute
  message: { message: "Too many requests, please try again later" },
  standardHeaders: true,
  legacyHeaders: false,
  store: createStore("api"),
});

// Auth endpoints (stricter)
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // 10 attempts per 15 minutes
  message: { message: "Too many login attempts, please try again later" },
  standardHeaders: true,
  legacyHeaders: false,
  store: createStore("auth"),
  skipSuccessfulRequests: true,
});

// AI/expensive operations
export const expensiveLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 10, // 10 AI requests per minute
  message: { message: "AI request limit reached, please wait" },
  standardHeaders: true,
  legacyHeaders: false,
  store: createStore("expensive"),
});

// Critical operations (payments, etc.)
export const criticalLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 20, // 20 critical operations per hour
  message: { message: "Operation limit reached, please try again later" },
  standardHeaders: true,
  legacyHeaders: false,
  store: createStore("critical"),
});

// File upload limit
export const uploadLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 50, // 50 uploads per hour
  message: { message: "Upload limit reached, please try again later" },
  standardHeaders: true,
  legacyHeaders: false,
  store: createStore("upload"),
});
```

---

## Summary: Infrastructure Improvements

| Feature | Purpose | Priority |
|---------|---------|----------|
| **Soft Delete** | Data recovery, audit trail | High |
| **Redis Cache** | Reduce DB load, faster responses | High |
| **File Validation** | Security, prevent malicious uploads | Critical |
| **Sentry Integration** | Error tracking in production | High |
| **Enhanced Rate Limiting** | Prevent abuse, protect AI costs | Medium |

These changes create a more robust foundation for scaling.
