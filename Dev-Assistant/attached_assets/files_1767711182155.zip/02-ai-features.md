# AI-Powered Features for hndld

## Overview
You have `services/ai-provider.ts` with Anthropic/OpenAI abstraction but aren't using it. Here's how to add meaningful AI features throughout the app.

---

## 1. Natural Language Request Parser

Let clients type requests naturally: "Can someone pick up my dry cleaning tomorrow afternoon?"

### File: `server/services/ai-request-parser.ts` (create new)

```typescript
import { getAIProvider } from "./ai-provider";

interface ParsedRequest {
  title: string;
  description?: string;
  category: "HOUSEHOLD" | "ERRANDS" | "MAINTENANCE" | "GROCERIES" | "KIDS" | "PETS" | "EVENTS" | "OTHER";
  urgency: "LOW" | "MEDIUM" | "HIGH";
  suggestedDueDate?: string; // ISO date string
  location?: string;
  extractedDetails: {
    people?: string[];
    items?: string[];
    times?: string[];
    places?: string[];
  };
  confidence: number;
}

const SYSTEM_PROMPT = `You are a task parser for a household concierge app. Extract structured task information from natural language requests.

Current date/time: {{currentDateTime}}

Categories:
- HOUSEHOLD: Cleaning, organizing, home tasks
- ERRANDS: Shopping, pickups, drop-offs, returns
- MAINTENANCE: Repairs, installations, home maintenance
- GROCERIES: Food shopping, meal prep supplies
- KIDS: School, activities, childcare related
- PETS: Pet care, vet visits, supplies
- EVENTS: Parties, gatherings, reservations
- OTHER: Anything that doesn't fit above

Urgency:
- HIGH: Today or ASAP, time-sensitive, important appointments
- MEDIUM: This week, normal priority
- LOW: Whenever possible, no rush

Respond ONLY with valid JSON matching this schema:
{
  "title": "concise task title (5-8 words max)",
  "description": "additional context if any",
  "category": "one of the categories above",
  "urgency": "HIGH, MEDIUM, or LOW",
  "suggestedDueDate": "ISO date string if time mentioned, null otherwise",
  "location": "location if mentioned",
  "extractedDetails": {
    "people": ["names mentioned"],
    "items": ["specific items"],
    "times": ["time references"],
    "places": ["locations"]
  },
  "confidence": 0.0-1.0
}`;

export async function parseNaturalLanguageRequest(
  userInput: string,
  householdContext?: {
    familyMembers?: string[];
    frequentLocations?: string[];
    recentTasks?: string[];
  }
): Promise<ParsedRequest> {
  const ai = getAIProvider();
  
  const currentDateTime = new Date().toLocaleString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZoneName: "short"
  });

  let contextAddition = "";
  if (householdContext) {
    if (householdContext.familyMembers?.length) {
      contextAddition += `\nFamily members: ${householdContext.familyMembers.join(", ")}`;
    }
    if (householdContext.frequentLocations?.length) {
      contextAddition += `\nFrequent locations: ${householdContext.frequentLocations.join(", ")}`;
    }
  }

  const systemPrompt = SYSTEM_PROMPT.replace("{{currentDateTime}}", currentDateTime) + contextAddition;

  try {
    const response = await ai.complete({
      systemPrompt,
      userMessage: userInput,
      maxTokens: 500,
      temperature: 0.3, // Low temperature for structured output
    });

    // Parse JSON from response
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No JSON found in response");
    }

    const parsed = JSON.parse(jsonMatch[0]) as ParsedRequest;
    
    // Validate required fields
    if (!parsed.title || !parsed.category || !parsed.urgency) {
      throw new Error("Missing required fields");
    }

    return parsed;
  } catch (error) {
    console.error("AI parsing failed:", error);
    
    // Fallback: basic parsing
    return {
      title: userInput.slice(0, 100),
      category: "OTHER",
      urgency: "MEDIUM",
      extractedDetails: {},
      confidence: 0.3
    };
  }
}

// Quick parse for simple inputs (faster, cheaper)
export function quickParseRequest(input: string): Partial<ParsedRequest> {
  const lowered = input.toLowerCase();
  
  // Category detection
  let category: ParsedRequest["category"] = "OTHER";
  if (/grocery|food|market|store|shopping/.test(lowered)) category = "GROCERIES";
  else if (/clean|organize|laundry|dishes/.test(lowered)) category = "HOUSEHOLD";
  else if (/pick up|drop off|return|errand|dry clean/.test(lowered)) category = "ERRANDS";
  else if (/repair|fix|install|plumb|electric|hvac/.test(lowered)) category = "MAINTENANCE";
  else if (/kid|school|soccer|practice|homework/.test(lowered)) category = "KIDS";
  else if (/dog|cat|pet|vet|walk/.test(lowered)) category = "PETS";
  else if (/party|dinner|reserv|event|birthday/.test(lowered)) category = "EVENTS";

  // Urgency detection
  let urgency: ParsedRequest["urgency"] = "MEDIUM";
  if (/asap|urgent|today|now|immediately|emergency/.test(lowered)) urgency = "HIGH";
  else if (/whenever|no rush|low priority|when you can/.test(lowered)) urgency = "LOW";

  return { category, urgency };
}
```

---

## 2. API Endpoint for AI Request Parsing

### File: `server/routes.ts` - Add endpoint:

```typescript
import { parseNaturalLanguageRequest, quickParseRequest } from "./services/ai-request-parser";

// AI-powered request parsing
app.post("/api/ai/parse-request", isAuthenticated, householdContext, expensiveLimiter, async (req: any, res) => {
  try {
    const { text, useAI = true } = req.body;
    const householdId = req.householdId!;

    if (!text || text.length < 3) {
      return res.status(400).json({ message: "Request text too short" });
    }

    if (!useAI) {
      // Quick parse without AI
      const quickResult = quickParseRequest(text);
      return res.json({
        ...quickResult,
        title: text.slice(0, 100),
        confidence: 0.5,
        usedAI: false
      });
    }

    // Get household context for better parsing
    const [people, locations] = await Promise.all([
      storage.getPeople(householdId),
      storage.getHouseholdLocations(householdId)
    ]);

    const result = await parseNaturalLanguageRequest(text, {
      familyMembers: people.map(p => p.name),
      frequentLocations: locations.map(l => l.name)
    });

    res.json({ ...result, usedAI: true });
  } catch (error) {
    console.error("AI parse error:", error);
    res.status(500).json({ message: "Failed to parse request" });
  }
});
```

---

## 3. Client: Smart Request Input Component

### File: `client/src/components/smart-request-input.tsx` (create new)

```typescript
import { useState, useCallback } from "react";
import { useMutation } from "@tanstack/react-query";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Sparkles, 
  Send, 
  Clock, 
  MapPin, 
  Tag,
  AlertCircle,
  Check,
  X
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

interface ParsedRequest {
  title: string;
  description?: string;
  category: string;
  urgency: string;
  suggestedDueDate?: string;
  location?: string;
  confidence: number;
  usedAI: boolean;
}

interface SmartRequestInputProps {
  onSubmit: (data: {
    title: string;
    description?: string;
    category: string;
    urgency: string;
    dueAt?: Date;
    location?: string;
  }) => void;
  isSubmitting?: boolean;
  placeholder?: string;
}

const CATEGORY_COLORS: Record<string, string> = {
  HOUSEHOLD: "bg-blue-100 text-blue-700",
  ERRANDS: "bg-amber-100 text-amber-700",
  MAINTENANCE: "bg-orange-100 text-orange-700",
  GROCERIES: "bg-green-100 text-green-700",
  KIDS: "bg-pink-100 text-pink-700",
  PETS: "bg-purple-100 text-purple-700",
  EVENTS: "bg-indigo-100 text-indigo-700",
  OTHER: "bg-gray-100 text-gray-700",
};

const URGENCY_COLORS: Record<string, string> = {
  HIGH: "bg-red-100 text-red-700",
  MEDIUM: "bg-amber-100 text-amber-700",
  LOW: "bg-green-100 text-green-700",
};

export function SmartRequestInput({ 
  onSubmit, 
  isSubmitting,
  placeholder = "What do you need help with? Try: 'Pick up dry cleaning tomorrow afternoon'"
}: SmartRequestInputProps) {
  const [input, setInput] = useState("");
  const [parsed, setParsed] = useState<ParsedRequest | null>(null);
  const [showPreview, setShowPreview] = useState(false);

  const parseMutation = useMutation({
    mutationFn: async (text: string) => {
      const response = await apiRequest("POST", "/api/ai/parse-request", { text });
      return response.json();
    },
    onSuccess: (data: ParsedRequest) => {
      setParsed(data);
      setShowPreview(true);
    },
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    setShowPreview(false);
    setParsed(null);
  };

  const handleParse = useCallback(() => {
    if (input.trim().length >= 3) {
      parseMutation.mutate(input.trim());
    }
  }, [input, parseMutation]);

  const handleConfirm = () => {
    if (!parsed) return;
    
    onSubmit({
      title: parsed.title,
      description: parsed.description,
      category: parsed.category,
      urgency: parsed.urgency,
      dueAt: parsed.suggestedDueDate ? new Date(parsed.suggestedDueDate) : undefined,
      location: parsed.location,
    });

    // Reset
    setInput("");
    setParsed(null);
    setShowPreview(false);
  };

  const handleReject = () => {
    setShowPreview(false);
    // Keep input for manual editing
  };

  return (
    <div className="space-y-3">
      <div className="relative">
        <Textarea
          value={input}
          onChange={handleInputChange}
          placeholder={placeholder}
          className="min-h-[80px] pr-24 resize-none"
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleParse();
            }
          }}
        />
        <div className="absolute bottom-2 right-2 flex items-center gap-2">
          {input.length > 0 && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                setInput("");
                setParsed(null);
                setShowPreview(false);
              }}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
          <Button
            size="sm"
            onClick={handleParse}
            disabled={input.trim().length < 3 || parseMutation.isPending}
            className="gap-1"
          >
            {parseMutation.isPending ? (
              <Sparkles className="h-4 w-4 animate-pulse" />
            ) : (
              <Sparkles className="h-4 w-4" />
            )}
            Parse
          </Button>
        </div>
      </div>

      {/* AI Parsing Indicator */}
      {parseMutation.isPending && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Sparkles className="h-5 w-5 text-primary animate-pulse" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Parsed Preview */}
      {showPreview && parsed && (
        <Card className="border-primary/50 bg-primary/5">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <p className="font-medium">{parsed.title}</p>
                {parsed.description && (
                  <p className="text-sm text-muted-foreground mt-1">{parsed.description}</p>
                )}
              </div>
              <div className="flex items-center gap-1">
                {parsed.usedAI && (
                  <Badge variant="outline" className="text-xs">
                    <Sparkles className="h-3 w-3 mr-1" />
                    AI
                  </Badge>
                )}
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Badge className={cn("text-xs", CATEGORY_COLORS[parsed.category])}>
                <Tag className="h-3 w-3 mr-1" />
                {parsed.category}
              </Badge>
              <Badge className={cn("text-xs", URGENCY_COLORS[parsed.urgency])}>
                <AlertCircle className="h-3 w-3 mr-1" />
                {parsed.urgency}
              </Badge>
              {parsed.suggestedDueDate && (
                <Badge variant="secondary" className="text-xs">
                  <Clock className="h-3 w-3 mr-1" />
                  {format(new Date(parsed.suggestedDueDate), "MMM d, h:mm a")}
                </Badge>
              )}
              {parsed.location && (
                <Badge variant="secondary" className="text-xs">
                  <MapPin className="h-3 w-3 mr-1" />
                  {parsed.location}
                </Badge>
              )}
            </div>

            {parsed.confidence < 0.7 && (
              <p className="text-xs text-muted-foreground">
                Low confidence ({Math.round(parsed.confidence * 100)}%) - you may want to review
              </p>
            )}

            <div className="flex items-center gap-2 pt-2">
              <Button
                size="sm"
                onClick={handleConfirm}
                disabled={isSubmitting}
                className="flex-1"
              >
                <Check className="h-4 w-4 mr-1" />
                {isSubmitting ? "Creating..." : "Create Request"}
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={handleReject}
              >
                Edit
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
```

---

## 4. Weekly Brief Generator

Generate a summary of the week for clients.

### File: `server/services/ai-weekly-brief.ts` (create new)

```typescript
import { getAIProvider } from "./ai-provider";
import { storage } from "../storage";
import { format, startOfWeek, endOfWeek, subWeeks } from "date-fns";

interface WeeklyBriefData {
  tasksCompleted: number;
  tasksInProgress: number;
  approvalsNeeded: number;
  upcomingEvents: any[];
  spendingSummary: {
    total: number;
    byCategory: Record<string, number>;
  };
  highlights: string[];
}

const BRIEF_SYSTEM_PROMPT = `You are a household assistant writing a weekly summary for a client. Write in a warm, professional tone. Keep it concise and actionable.

Structure:
1. Opening (1 sentence greeting with key highlight)
2. Accomplishments (bullet points of completed tasks)
3. In Progress (what's being worked on)
4. Needs Attention (approvals, decisions needed)
5. Upcoming (events, deadlines this week)
6. Spending snapshot (if any)
7. Closing (1 sentence)

Keep total length under 300 words. Use the household name if provided.`;

export async function generateWeeklyBrief(
  householdId: string,
  householdName?: string
): Promise<{ brief: string; data: WeeklyBriefData }> {
  const ai = getAIProvider();
  
  const now = new Date();
  const weekStart = startOfWeek(now);
  const weekEnd = endOfWeek(now);
  const lastWeekStart = startOfWeek(subWeeks(now, 1));

  // Gather data
  const [tasks, approvals, updates, spending, events] = await Promise.all([
    storage.getTasks(householdId),
    storage.getApprovals(householdId),
    storage.getUpdates(householdId),
    storage.getSpendingItems(householdId),
    storage.getCalendarEvents(householdId)
  ]);

  // Process tasks
  const completedThisWeek = tasks.filter(t => 
    t.status === "DONE" && 
    t.updatedAt && 
    new Date(t.updatedAt) >= lastWeekStart
  );
  const inProgress = tasks.filter(t => 
    t.status === "IN_PROGRESS" || t.status === "PLANNED"
  );

  // Process approvals
  const pendingApprovals = approvals.filter(a => a.status === "PENDING");

  // Process spending
  const weekSpending = spending.filter(s => 
    s.date && new Date(s.date) >= lastWeekStart
  );
  const spendingByCategory: Record<string, number> = {};
  weekSpending.forEach(s => {
    const cat = s.category || "Other";
    spendingByCategory[cat] = (spendingByCategory[cat] || 0) + s.amount;
  });
  const totalSpending = weekSpending.reduce((sum, s) => sum + s.amount, 0);

  // Process events
  const upcomingEvents = events.filter(e => {
    const start = new Date(e.startTime);
    return start >= now && start <= weekEnd;
  }).slice(0, 5);

  // Build context for AI
  const context = {
    householdName: householdName || "your household",
    weekOf: format(weekStart, "MMMM d"),
    completedTasks: completedThisWeek.map(t => t.title).slice(0, 10),
    inProgressTasks: inProgress.map(t => t.title).slice(0, 5),
    pendingApprovals: pendingApprovals.map(a => ({
      title: a.title,
      amount: a.amount ? `$${(a.amount / 100).toFixed(2)}` : null
    })),
    upcomingEvents: upcomingEvents.map(e => ({
      title: e.title,
      date: format(new Date(e.startTime), "EEEE, MMM d 'at' h:mm a")
    })),
    spending: totalSpending > 0 ? {
      total: `$${(totalSpending / 100).toFixed(2)}`,
      byCategory: Object.entries(spendingByCategory).map(([cat, amount]) => 
        `${cat}: $${(amount / 100).toFixed(2)}`
      )
    } : null,
    recentUpdates: updates.slice(0, 3).map(u => u.text.slice(0, 100))
  };

  const userMessage = `Generate a weekly brief with this data:
${JSON.stringify(context, null, 2)}`;

  const brief = await ai.complete({
    systemPrompt: BRIEF_SYSTEM_PROMPT,
    userMessage,
    maxTokens: 800,
    temperature: 0.7,
  });

  return {
    brief,
    data: {
      tasksCompleted: completedThisWeek.length,
      tasksInProgress: inProgress.length,
      approvalsNeeded: pendingApprovals.length,
      upcomingEvents,
      spendingSummary: {
        total: totalSpending,
        byCategory: spendingByCategory
      },
      highlights: completedThisWeek.slice(0, 3).map(t => t.title)
    }
  };
}
```

### Add API endpoint:

```typescript
// Weekly brief generation
app.get("/api/ai/weekly-brief", isAuthenticated, householdContext, expensiveLimiter, async (req: any, res) => {
  try {
    const householdId = req.householdId!;
    const household = await storage.getHousehold(householdId);
    
    const result = await generateWeeklyBrief(householdId, household?.name);
    res.json(result);
  } catch (error) {
    console.error("Weekly brief error:", error);
    res.status(500).json({ message: "Failed to generate brief" });
  }
});
```

---

## 5. Smart Expense Categorization

### File: `server/services/ai-expense-categorizer.ts` (create new)

```typescript
import { getAIProvider } from "./ai-provider";

const CATEGORIES = [
  "Groceries",
  "Household", 
  "Utilities",
  "Maintenance",
  "Services",
  "Kids",
  "Pets",
  "Entertainment",
  "Transportation",
  "Health",
  "Other"
];

interface CategorizedExpense {
  category: string;
  confidence: number;
  suggestedVendorType?: string;
}

// Fast rule-based categorization
export function quickCategorize(vendor: string, note?: string): CategorizedExpense {
  const text = `${vendor} ${note || ""}`.toLowerCase();
  
  // Groceries
  if (/whole foods|trader joe|safeway|kroger|costco|grocery|market|food/.test(text)) {
    return { category: "Groceries", confidence: 0.9 };
  }
  
  // Household
  if (/target|walmart|home depot|lowes|ikea|bed bath|container store/.test(text)) {
    return { category: "Household", confidence: 0.8 };
  }
  
  // Utilities
  if (/electric|gas|water|internet|comcast|verizon|att|utility/.test(text)) {
    return { category: "Utilities", confidence: 0.9 };
  }
  
  // Maintenance
  if (/plumb|electric|hvac|repair|handyman|landscap|pool|clean/.test(text)) {
    return { category: "Maintenance", confidence: 0.85 };
  }
  
  // Kids
  if (/school|tutor|daycare|toy|kid|child|baby/.test(text)) {
    return { category: "Kids", confidence: 0.85 };
  }
  
  // Pets
  if (/vet|petco|petsmart|pet|dog|cat|groomer/.test(text)) {
    return { category: "Pets", confidence: 0.9 };
  }
  
  // Entertainment
  if (/restaurant|movie|theatre|concert|subscription|netflix|spotify/.test(text)) {
    return { category: "Entertainment", confidence: 0.8 };
  }
  
  // Transportation
  if (/uber|lyft|gas station|parking|car wash|auto/.test(text)) {
    return { category: "Transportation", confidence: 0.85 };
  }
  
  // Health
  if (/pharmacy|cvs|walgreens|doctor|dental|medical|health/.test(text)) {
    return { category: "Health", confidence: 0.85 };
  }

  return { category: "Other", confidence: 0.3 };
}

// AI-powered categorization for uncertain cases
export async function aiCategorize(
  vendor: string,
  amount: number,
  note?: string
): Promise<CategorizedExpense> {
  // Try quick categorization first
  const quick = quickCategorize(vendor, note);
  if (quick.confidence >= 0.8) {
    return quick;
  }

  // Fall back to AI
  const ai = getAIProvider();
  
  const response = await ai.complete({
    systemPrompt: `You categorize household expenses. Respond with ONLY a JSON object.
Categories: ${CATEGORIES.join(", ")}

Output format:
{"category": "CategoryName", "confidence": 0.0-1.0, "suggestedVendorType": "brief description"}`,
    userMessage: `Vendor: ${vendor}
Amount: $${(amount / 100).toFixed(2)}
Note: ${note || "none"}`,
    maxTokens: 100,
    temperature: 0.3,
  });

  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
  } catch (e) {
    console.error("AI categorization parse error:", e);
  }

  return quick; // Fall back to quick categorization
}
```

---

## 6. AI Chat Assistant

Allow users to ask questions about their household.

### File: `server/services/ai-chat.ts` (create new)

```typescript
import { getAIProvider } from "./ai-provider";
import { storage } from "../storage";

interface ChatContext {
  householdId: string;
  userId: string;
  userRole: "CLIENT" | "ASSISTANT";
  householdName?: string;
}

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

const ASSISTANT_SYSTEM_PROMPT = `You are a helpful AI assistant for hndld, a household concierge app. You help clients and assistants manage their household tasks, schedules, and requests.

You have access to the following household information:
{{householdContext}}

Guidelines:
- Be concise and helpful
- If asked about specific data you don't have, say so
- You can help with:
  - Summarizing tasks and their status
  - Explaining spending and budgets
  - Answering questions about schedules
  - Providing suggestions for household management
- You cannot:
  - Create, update, or delete data (suggest the user do this in the app)
  - Access data from other households
  - Provide financial or legal advice

Keep responses under 200 words unless specifically asked for detail.`;

export async function chatWithAssistant(
  context: ChatContext,
  messages: ChatMessage[],
  newMessage: string
): Promise<string> {
  const ai = getAIProvider();

  // Gather household context
  const [tasks, approvals, spending, people, settings] = await Promise.all([
    storage.getTasks(context.householdId),
    storage.getApprovals(context.householdId),
    storage.getSpendingItems(context.householdId),
    storage.getPeople(context.householdId),
    storage.getHouseholdSettings(context.householdId)
  ]);

  const householdContext = `
Household: ${context.householdName || "Unknown"}
User Role: ${context.userRole}

Tasks Summary:
- Total: ${tasks.length}
- In Progress: ${tasks.filter(t => t.status === "IN_PROGRESS").length}
- Waiting: ${tasks.filter(t => t.status === "WAITING_ON_CLIENT").length}
- Completed: ${tasks.filter(t => t.status === "DONE").length}

Pending Approvals: ${approvals.filter(a => a.status === "PENDING").length}

Recent Tasks: ${tasks.slice(0, 5).map(t => `"${t.title}" (${t.status})`).join(", ")}

Family Members: ${people.map(p => p.name).join(", ") || "Not specified"}

This Month's Spending: $${(spending.filter(s => {
    const date = s.date ? new Date(s.date) : new Date(s.createdAt!);
    const now = new Date();
    return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
  }).reduce((sum, s) => sum + s.amount, 0) / 100).toFixed(2)}
`;

  const systemPrompt = ASSISTANT_SYSTEM_PROMPT.replace("{{householdContext}}", householdContext);

  // Build conversation
  const conversationMessages = messages.map(m => ({
    role: m.role as "user" | "assistant",
    content: m.content
  }));

  // Add new message
  conversationMessages.push({ role: "user", content: newMessage });

  const response = await ai.chat({
    systemPrompt,
    messages: conversationMessages,
    maxTokens: 500,
    temperature: 0.7,
  });

  return response;
}
```

### Add chat endpoint:

```typescript
// AI Chat endpoint
app.post("/api/ai/chat", isAuthenticated, householdContext, expensiveLimiter, async (req: any, res) => {
  try {
    const { messages, newMessage } = req.body;
    const userId = req.user.claims.sub;
    const householdId = req.householdId!;
    
    const userProfile = await storage.getUserProfile(userId, householdId);
    const household = await storage.getHousehold(householdId);

    const response = await chatWithAssistant(
      {
        householdId,
        userId,
        userRole: userProfile?.role || "CLIENT",
        householdName: household?.name
      },
      messages || [],
      newMessage
    );

    res.json({ response });
  } catch (error) {
    console.error("AI chat error:", error);
    res.status(500).json({ message: "Failed to get response" });
  }
});
```

---

## 7. AI Provider Interface Update

Make sure your AI provider supports both completion and chat.

### File: `server/services/ai-provider.ts` - Update interface:

```typescript
export interface AIProvider {
  complete(options: {
    systemPrompt: string;
    userMessage: string;
    maxTokens?: number;
    temperature?: number;
  }): Promise<string>;

  chat(options: {
    systemPrompt: string;
    messages: Array<{ role: "user" | "assistant"; content: string }>;
    maxTokens?: number;
    temperature?: number;
  }): Promise<string>;
}

// Anthropic implementation
class AnthropicProvider implements AIProvider {
  private client: Anthropic;

  constructor() {
    this.client = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY,
    });
  }

  async complete(options: Parameters<AIProvider["complete"]>[0]): Promise<string> {
    const response = await this.client.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: options.maxTokens || 1024,
      system: options.systemPrompt,
      messages: [{ role: "user", content: options.userMessage }],
    });

    return response.content[0].type === "text" ? response.content[0].text : "";
  }

  async chat(options: Parameters<AIProvider["chat"]>[0]): Promise<string> {
    const response = await this.client.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: options.maxTokens || 1024,
      system: options.systemPrompt,
      messages: options.messages.map(m => ({
        role: m.role,
        content: m.content,
      })),
    });

    return response.content[0].type === "text" ? response.content[0].text : "";
  }
}
```

---

## 8. Client: AI Chat Component

### File: `client/src/components/ai-chat.tsx` (create new)

```typescript
import { useState, useRef, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Sparkles, Send, X, Minimize2, Maximize2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";

interface Message {
  role: "user" | "assistant";
  content: string;
}

export function AIChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const chatMutation = useMutation({
    mutationFn: async (newMessage: string) => {
      const response = await apiRequest("POST", "/api/ai/chat", {
        messages,
        newMessage
      });
      return response.json();
    },
    onSuccess: (data) => {
      setMessages(prev => [...prev, { role: "assistant", content: data.response }]);
    },
  });

  const handleSend = () => {
    if (!input.trim() || chatMutation.isPending) return;
    
    const userMessage = input.trim();
    setMessages(prev => [...prev, { role: "user", content: userMessage }]);
    setInput("");
    chatMutation.mutate(userMessage);
  };

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  if (!isOpen) {
    return (
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 right-4 z-50 h-14 w-14 rounded-full shadow-lg"
        size="icon"
      >
        <Sparkles className="h-6 w-6" />
      </Button>
    );
  }

  return (
    <Card className={cn(
      "fixed right-4 z-50 shadow-xl transition-all duration-200",
      isMinimized 
        ? "bottom-24 w-72 h-14" 
        : "bottom-24 w-80 sm:w-96 h-[500px] max-h-[70vh]"
    )}>
      <CardHeader className="p-3 border-b flex flex-row items-center justify-between">
        <CardTitle className="text-sm flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          AI Assistant
        </CardTitle>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setIsMinimized(!isMinimized)}
          >
            {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setIsOpen(false)}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>

      {!isMinimized && (
        <>
          <ScrollArea className="flex-1 p-3" ref={scrollRef}>
            <div className="space-y-4">
              {messages.length === 0 && (
                <div className="text-center text-muted-foreground py-8">
                  <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Ask me anything about your household!</p>
                  <p className="text-xs mt-1">Try: "What's on my schedule this week?"</p>
                </div>
              )}
              
              {messages.map((message, i) => (
                <div
                  key={i}
                  className={cn(
                    "flex gap-2",
                    message.role === "user" ? "justify-end" : "justify-start"
                  )}
                >
                  {message.role === "assistant" && (
                    <Avatar className="h-7 w-7">
                      <AvatarFallback className="bg-primary/10 text-primary text-xs">
                        <Sparkles className="h-3 w-3" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                  <div
                    className={cn(
                      "max-w-[80%] rounded-xl px-3 py-2 text-sm",
                      message.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    )}
                  >
                    {message.content}
                  </div>
                </div>
              ))}

              {chatMutation.isPending && (
                <div className="flex gap-2">
                  <Avatar className="h-7 w-7">
                    <AvatarFallback className="bg-primary/10 text-primary text-xs">
                      <Sparkles className="h-3 w-3 animate-pulse" />
                    </AvatarFallback>
                  </Avatar>
                  <div className="bg-muted rounded-xl px-3 py-2">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" />
                      <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce delay-75" />
                      <span className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce delay-150" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="p-3 border-t">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex gap-2"
            >
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask anything..."
                className="flex-1"
                disabled={chatMutation.isPending}
              />
              <Button
                type="submit"
                size="icon"
                disabled={!input.trim() || chatMutation.isPending}
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </>
      )}
    </Card>
  );
}
```

---

## Summary: AI Features to Add

| Feature | Endpoint | Purpose |
|---------|----------|---------|
| Request Parser | `POST /api/ai/parse-request` | NLP task creation |
| Weekly Brief | `GET /api/ai/weekly-brief` | Automated summaries |
| Expense Categorization | Called internally | Auto-categorize spending |
| Chat Assistant | `POST /api/ai/chat` | Q&A about household |
| Smart Suggestions | Coming next | Predictive task suggestions |

Add the `AIChat` component to your `AppLayout` to make it available app-wide.
