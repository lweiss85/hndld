# hndld Implementation Roadmap

## Priority Matrix

| Priority | Feature | Effort | Impact | Files |
|----------|---------|--------|--------|-------|
| 🔴 P0 | WebSocket Real-time | 1 week | Critical | 01-websocket-realtime.md |
| 🔴 P0 | Offline/PWA | 1 week | Critical | 03-offline-pwa.md |
| 🔴 P0 | Sentry Error Tracking | 2 days | Critical | 04-infrastructure.md |
| 🟠 P1 | AI Request Parser | 3 days | High | 02-ai-features.md |
| 🟠 P1 | AI Chat Assistant | 3 days | High | 02-ai-features.md |
| 🟠 P1 | File Upload Security | 2 days | High | 04-infrastructure.md |
| 🟡 P2 | Redis Caching | 3 days | Medium | 04-infrastructure.md |
| 🟡 P2 | Soft Delete | 2 days | Medium | 04-infrastructure.md |
| 🟡 P2 | Weekly Brief Generator | 2 days | Medium | 02-ai-features.md |
| 🟢 P3 | Expense Auto-categorize | 1 day | Low | 02-ai-features.md |

---

## Sprint 1: Foundation (Week 1-2)

### Goals
- Real-time updates working
- Basic offline support
- Production error tracking

### Tasks

**Day 1-3: WebSocket**
```bash
# Files to create/modify:
server/services/websocket.ts          # New - WS manager
server/index.ts                        # Add WS initialization  
server/routes.ts                       # Add broadcasts to mutations
client/src/hooks/use-websocket.ts      # New - WS hook
client/src/lib/websocket-context.tsx   # New - Provider
client/src/App.tsx                     # Wrap with provider
```

**Day 4-5: Sentry**
```bash
npm install @sentry/node @sentry/profiling-node

# Files to create/modify:
server/lib/error-handler.ts            # New - Error handling
server/index.ts                        # Initialize Sentry
.env                                   # Add SENTRY_DSN
```

**Day 6-10: Service Worker**
```bash
npm install vite-plugin-pwa workbox-precaching workbox-routing workbox-strategies workbox-expiration workbox-background-sync workbox-cacheable-response

# Files to create/modify:
client/src/sw.ts                       # New - Service worker
vite.config.ts                         # Add PWA plugin
client/src/lib/sw-registration.ts      # New - SW registration
client/src/hooks/use-online-status.ts  # New - Online detection
client/src/components/offline-banner.tsx # New - Offline UI
client/src/main.tsx                    # Register SW
```

---

## Sprint 2: AI Integration (Week 3-4)

### Goals
- Natural language task creation
- AI chat assistant
- Smart expense categorization

### Tasks

**Day 1-3: Request Parser**
```bash
# Files to create/modify:
server/services/ai-request-parser.ts   # New - NLP parser
server/routes.ts                       # Add /api/ai/parse-request
client/src/components/smart-request-input.tsx # New - Smart input UI
```

**Day 4-6: Chat Assistant**
```bash
# Files to create/modify:
server/services/ai-chat.ts             # New - Chat logic
server/routes.ts                       # Add /api/ai/chat
client/src/components/ai-chat.tsx      # New - Chat UI
client/src/components/layout/app-layout.tsx # Add chat button
```

**Day 7-8: Expense Categorization**
```bash
# Files to create/modify:
server/services/ai-expense-categorizer.ts # New - Categorizer
server/routes.ts                       # Update expense creation to auto-categorize
```

**Day 9-10: Weekly Brief**
```bash
# Files to create/modify:
server/services/ai-weekly-brief.ts     # New - Brief generator
server/routes.ts                       # Add /api/ai/weekly-brief
client/src/pages/this-week.tsx         # Add brief section for clients
```

---

## Sprint 3: Polish (Week 5-6)

### Goals
- Redis caching for performance
- File upload security
- Soft delete for data safety

### Tasks

**Day 1-3: Redis Cache**
```bash
npm install ioredis

# Files to create/modify:
server/services/cache.ts               # New - Cache service
server/routes.ts                       # Wrap expensive queries
.env                                   # Add REDIS_URL
```

**Day 4-5: File Security**
```bash
npm install file-type

# Files to create/modify:
server/middleware/file-validation.ts   # New - Validation middleware
server/routes/files.ts                 # Add validation to upload
```

**Day 6-8: Soft Delete**
```bash
# Files to create/modify:
shared/schema.ts                       # Add deletedAt, deletedBy fields
server/storage.ts                      # Update delete methods
server/routes.ts                       # Update delete endpoints
# Run migration
```

---

## Quick Wins (Can Do Anytime)

### 1. Add Connection Indicator
```typescript
// client/src/components/connection-status.tsx
// Shows green dot when connected, amber when reconnecting
```

### 2. Add Loading States
```typescript
// Improve skeleton screens for better perceived performance
```

### 3. Add Haptic Feedback
```typescript
// Already have triggerHaptic() - use it more consistently
```

### 4. Improve Empty States
```typescript
// Make empty states more actionable with CTAs
```

---

## Environment Variables Needed

```env
# Add to .env
SENTRY_DSN=https://xxx@sentry.io/xxx
REDIS_URL=redis://localhost:6379
ANTHROPIC_API_KEY=sk-ant-xxx  # Already have this

# Optional
OPENAI_API_KEY=sk-xxx         # Fallback AI provider
```

---

## Testing Checklist

### WebSocket
- [ ] Open app in 2 windows
- [ ] Create task in window 1
- [ ] Window 2 shows toast + updates list

### Offline
- [ ] Load app online
- [ ] Disable network in DevTools
- [ ] Create a task (should queue)
- [ ] Enable network
- [ ] Task syncs automatically

### AI Parser
- [ ] Type "Pick up dry cleaning tomorrow at 3pm"
- [ ] Should parse to:
  - Title: "Pick up dry cleaning"
  - Category: ERRANDS
  - Urgency: MEDIUM
  - Due: Tomorrow 3pm

### AI Chat
- [ ] Open chat bubble
- [ ] Ask "What's on my schedule?"
- [ ] Get contextual response

### Cache
- [ ] Load household settings
- [ ] Check Redis for cached data
- [ ] Update settings
- [ ] Verify cache invalidated

### Soft Delete
- [ ] Delete a task
- [ ] Verify it's hidden from lists
- [ ] Check DB - deletedAt should be set
- [ ] Restore task
- [ ] Verify it reappears

---

## Cost Considerations

### AI Usage
- Request parsing: ~500 tokens per request
- Chat: ~1000 tokens per message
- Weekly brief: ~2000 tokens per generation

**Estimated monthly costs (1000 users, moderate usage):**
- Anthropic API: $50-200/month
- Redis (managed): $15-50/month
- Sentry: Free tier → $26/month

---

## What Not to Do

1. **Don't over-cache** - Start with settings/profiles only
2. **Don't AI everything** - Use rule-based for simple categorization
3. **Don't skip validation** - File uploads are attack vectors
4. **Don't hard delete** - You'll regret it when someone asks to restore
5. **Don't skip error tracking** - You need visibility into production issues
