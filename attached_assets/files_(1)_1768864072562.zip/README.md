# hndld Tech Debt Fixes

## Overview

This package contains all the code needed to fix the critical tech debt issues in hndld. Each file is ready to drop into Replit.

## Priority Order

Apply these fixes in order:

### 🔴 CRITICAL (Security)

1. **XSS in Invoice Generation** - `server/lib/escape-html.ts` + route patch
2. **Vault Encryption** - `server/services/vault-encryption.ts` + route patch
3. **PII in Logs** - `server/lib/logger.ts`
4. **Session Secure Flag** - Patch in `server/replit_integrations/auth/replitAuth.ts`

### 🟡 HIGH (Functionality)

5. **Service Type Scoping** - `server/middleware/serviceScope.ts` + route patches
6. **Bottom Nav HTML** - `client/src/components/layout/bottom-nav.tsx`
7. **Stripe Constraint** - `migrations/001_unique_stripe_invoice_id.sql`

### 🟢 MEDIUM (Tech Debt)

8. **Invoice File Writing** - Patch in routes.ts
9. **Payment Profile 404** - One-line fix in payment-profile.tsx

---

## Installation Steps

### Step 1: Add New Files

Copy these files to your Replit project:

```
server/lib/escape-html.ts          → NEW FILE
server/lib/logger.ts               → REPLACE existing
server/services/vault-encryption.ts → NEW FILE
server/middleware/serviceScope.ts   → NEW FILE
client/src/components/layout/bottom-nav.tsx → REPLACE existing
```

### Step 2: Add Environment Variable

Add to your Replit Secrets (or .env):

```bash
# Generate with: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
VAULT_ENCRYPTION_KEY=<your-64-character-hex-string>
```

### Step 3: Run SQL Migration

In your Replit database console, run:

```sql
-- See migrations/001_unique_stripe_invoice_id.sql
```

### Step 4: Apply Route Patches

Open `server/routes.ts` and apply these changes:

#### 4a. Add Imports (at top of file)

```typescript
import { escapeHtml } from "./lib/escape-html";
import { encryptVaultValue, decryptVaultValue } from "./services/vault-encryption";
import { serviceScopeMiddleware, getServiceTypeFilter } from "./middleware/serviceScope";
```

#### 4b. Fix Invoice Generation (around line 1758)

Replace the invoice HTML generation with the escaped version (see `PATCH_invoice_generation.ts`)

#### 4c. Fix Vault Endpoints (around line 2605-2670)

Add encryption on create/update, decryption on reveal (see `PATCH_vault_encryption.ts`)

#### 4d. Fix Session Config (server/replit_integrations/auth/replitAuth.ts line 37)

Change:
```typescript
secure: true,
```
To:
```typescript
secure: process.env.NODE_ENV === "production" || !!process.env.REPL_ID,
```

### Step 5: Add CSS Utility

Add to `client/src/index.css`:

```css
.scrollbar-hide::-webkit-scrollbar { display: none; }
.scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
```

### Step 6: Fix Payment Profile Link

In `client/src/pages/payment-profile.tsx`, change:
```typescript
href="/today"
```
To:
```typescript
href="/"
```

---

## Verification Checklist

After applying fixes, test:

- [ ] Create invoice with `<script>alert('xss')</script>` in title → should be escaped
- [ ] Login works in both HTTP (dev) and HTTPS (prod)
- [ ] Create vault item → check DB shows encrypted value (salt:iv:authTag:ciphertext format)
- [ ] Logs don't contain passwords or tokens
- [ ] Bottom nav works on mobile with VoiceOver
- [ ] CLEANING user can't see PA tasks (if service type feature is used)

---

## Files in This Package

```
tech-debt-fixes/
├── README.md                              # This file
├── server/
│   ├── lib/
│   │   ├── escape-html.ts                 # XSS prevention utility
│   │   └── logger.ts                      # PII-sanitizing logger
│   ├── services/
│   │   └── vault-encryption.ts            # AES-256-GCM encryption
│   └── middleware/
│       └── serviceScope.ts                # Service type filtering
├── client/
│   └── src/
│       └── components/
│           └── layout/
│               └── bottom-nav.tsx         # Fixed HTML nesting
├── migrations/
│   └── 001_unique_stripe_invoice_id.sql   # Stripe deduplication
└── PATCHES/
    ├── PATCH_invoice_generation.ts        # XSS-safe invoice code
    ├── PATCH_vault_encryption.ts          # Vault endpoint changes
    └── PATCH_session_config.ts            # Session secure flag fix
```
