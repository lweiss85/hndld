# hndld Tech Debt Fixes - Quick Start

## 5-Minute Fix Guide

### Step 1: Copy New Files (2 min)

Copy these files to your Replit project:

```
server/lib/escape-html.ts     → CREATE NEW
server/lib/logger.ts          → REPLACE
server/services/vault-encryption.ts → CREATE NEW
server/middleware/serviceScope.ts   → CREATE NEW
client/src/components/layout/bottom-nav.tsx → REPLACE
```

### Step 2: Add Environment Variable (30 sec)

In Replit Secrets, add:

```
VAULT_ENCRYPTION_KEY=<paste-64-char-hex-string>
```

Generate with:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Step 3: Add Imports to routes.ts (30 sec)

At the top of `server/routes.ts`, add:

```typescript
import { escapeHtml } from "./lib/escape-html";
import { encryptVaultValue, decryptVaultValue } from "./services/vault-encryption";
```

### Step 4: Fix Invoice XSS (1 min)

In `server/routes.ts`, find `/api/invoices/send` (around line 1730).

Before the HTML template, add:

```typescript
const safeTitle = escapeHtml(title);
const safeNote = escapeHtml(note);
const safeHouseholdName = escapeHtml(household?.name);
const safeVenmoUsername = escapeHtml(venmoUsername);
const safeZelleRecipient = escapeHtml(zelleRecipient);
```

Then use these `safe*` variables in the HTML instead of the raw values.

### Step 5: Fix Session Config (30 sec)

In `server/replit_integrations/auth/replitAuth.ts`, find line ~37:

Change:
```typescript
secure: true,
```

To:
```typescript
secure: process.env.NODE_ENV === "production" || !!process.env.REPL_ID,
```

### Step 6: Add CSS (30 sec)

Add to end of `client/src/index.css`:

```css
.scrollbar-hide::-webkit-scrollbar { display: none; }
.scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
```

### Step 7: Run SQL Migration

In Replit DB console, run:

```sql
ALTER TABLE invoices 
ADD CONSTRAINT invoices_stripe_invoice_id_unique 
UNIQUE (stripe_invoice_id);
```

---

## Done!

Test these:
- [ ] Login works
- [ ] Create invoice with `<script>alert(1)</script>` in title → should be escaped
- [ ] Logs don't show passwords

For full details, see README.md and PATCHES/ folder.
