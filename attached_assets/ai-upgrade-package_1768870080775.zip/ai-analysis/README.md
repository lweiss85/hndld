# Proactive AI Upgrade for hndld

## Overview

This package upgrades hndld's AI from **reactive utilities** to a **true proactive assistant**.

**Before:** AI responds when asked  
**After:** AI anticipates needs and reaches out proactively

---

## What's Included

| File | Purpose |
|------|---------|
| `HNDLD_AI_ANALYSIS.md` | Full analysis of current AI (what's missing) |
| `server/services/ai-agent.ts` | Core proactive AI agent |
| `server/services/scheduler-additions.ts` | Cron jobs for daily AI runs |
| `server/routes-additions.ts` | API endpoints for insights |
| `shared/schema-additions.ts` | Database tables for patterns & insights |
| `client/src/components/proactive-insights.tsx` | UI component |

---

## Quick Install (15 minutes)

### Step 1: Add Schema Tables

Copy the table definitions from `shared/schema-additions.ts` to your `shared/schema.ts`:

```typescript
// Add these to shared/schema.ts
export const proactiveInsights = pgTable("proactive_insights", { ... });
export const taskPatterns = pgTable("task_patterns", { ... });
export const conversationMemories = pgTable("conversation_memories", { ... });
export const learnedPreferences = pgTable("learned_preferences", { ... });
```

Then run:
```bash
npm run db:push
```

### Step 2: Add AI Agent Service

Copy `server/services/ai-agent.ts` to your project.

### Step 3: Update Scheduler

Add to your `server/services/scheduler.ts`:

```typescript
import { runProactiveAgent } from "./ai-agent";

// Add this job to your startAllSchedulers function
cron.schedule("0 8 * * *", async () => {
  await runProactiveAgent();
});

cron.schedule("0 18 * * *", async () => {
  await runProactiveAgent();
});
```

### Step 4: Add API Routes

Add the routes from `server/routes-additions.ts` to your `server/routes.ts`.

### Step 5: Add Client Component

Copy `client/src/components/proactive-insights.tsx` to your project.

### Step 6: Add to Dashboard

In your Today page or dashboard, add:

```tsx
import { ProactiveInsights } from "@/components/proactive-insights";

// In your component:
<ProactiveInsights />
```

---

## What It Does

### Daily at 8am & 6pm:

1. **Scans for overdue tasks** → Sends gentle nudges after 2+ days
2. **Checks upcoming dates** → Reminds 7, 3, 1 day before birthdays/anniversaries
3. **Analyzes tomorrow's schedule** → Warns if it's busy
4. **Reviews pending expenses** → Suggests invoicing when pile builds up
5. **Checks waiting tasks** → Prompts for follow-up after 3+ days

### Learns Over Time:

- Records actual task durations
- Builds household-specific time estimates
- Improves accuracy with more data

---

## Example Insights

**High Priority:**
> 🔴 "Call plumber" is 5 days overdue  
> This has been waiting a while. Should I reschedule it or remove it from your list?

**Medium Priority:**
> 🟡 Mom's Birthday is in 3 days  
> Time to think about a gift or card. Last year you ordered flowers from FTD.

**Low Priority:**
> ⚪ 5 expenses pending  
> $247.50 in reimbursements waiting. Ready to invoice your client?

---

## Configuration

### Environment Variables

```env
# Enable/disable proactive AI (default: true)
ENABLE_PROACTIVE_AI=true

# Requires an API key for AI-powered suggestions
ANTHROPIC_API_KEY=sk-ant-...
# or
OPENAI_API_KEY=sk-...
```

### Adjust Schedule

In `scheduler.ts`, change the cron expressions:

```typescript
// Current: 8am and 6pm
cron.schedule("0 8 * * *", ...)
cron.schedule("0 18 * * *", ...)

// Example: 7am and 9pm
cron.schedule("0 7 * * *", ...)
cron.schedule("0 21 * * *", ...)
```

---

## Testing

### Manual Trigger

Call the refresh endpoint to test immediately:

```bash
curl -X POST http://localhost:5000/api/ai/insights/refresh \
  -H "Cookie: your-session-cookie"
```

### Check Insights

```bash
curl http://localhost:5000/api/ai/insights \
  -H "Cookie: your-session-cookie"
```

---

## What This Changes

| Metric | Before | After |
|--------|--------|-------|
| AI Score | 4/10 | 7/10 |
| Proactive Notifications | ❌ | ✅ |
| Pattern Learning | ❌ | ✅ |
| Important Date Reminders | ❌ | ✅ |
| Overdue Task Escalation | ❌ | ✅ |
| Smart Time Estimates | ❌ | ✅ |

---

## Future Enhancements

To reach 9/10, add:

1. **Conversation Memory** - Remember past chat sessions
2. **Autonomous Task Creation** - AI creates tasks with user approval
3. **Vendor Relationship Tracking** - "Time to schedule the quarterly HVAC check"
4. **Multi-step Reasoning** - Chain calendar + tasks + preferences

These are outlined in the analysis document but not implemented in this package.

---

## Files Structure

```
ai-analysis/
├── HNDLD_AI_ANALYSIS.md              # Full analysis
├── README.md                          # This file
├── server/
│   ├── services/
│   │   ├── ai-agent.ts               # Core proactive agent
│   │   └── scheduler-additions.ts    # Cron job setup
│   └── routes-additions.ts           # API endpoints
├── shared/
│   └── schema-additions.ts           # Database tables
└── client/
    └── src/
        └── components/
            └── proactive-insights.tsx # UI component
```
