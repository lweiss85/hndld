# Apple-Grade UX: Depth & Feedback System

## What This Adds

This package elevates hndld from **A-/B+** to **A+** in Apple's UX principles for:

### Depth (A- → A+)
- **Materials**: Frosted glass backgrounds with proper blur and saturation
- **Elevation**: 5-level shadow system matching iOS
- **Sheet animations**: Background scales down and blurs when sheets open
- **Layered cards**: Hover states that increase elevation
- **Spring physics**: Timing curves that match UIKit

### Feedback (B+ → A+)
- **Haptic patterns**: 7 distinct haptic types (light, medium, heavy, success, warning, error, selection)
- **Success animations**: Animated checkmark with circle draw and burst effect
- **Loading states**: Button spinners that transition to success state
- **Skeleton loading**: Shimmer animation that matches content layout
- **Press feedback**: Scale-down on press with spring recovery
- **Toast notifications**: Haptic feedback on appearance
- **Progress indicators**: Ring and bar with smooth animations

---

## Quick Install (5 minutes)

### Step 1: Copy Files

```bash
# Create directory
mkdir -p client/src/components/apple-ux
mkdir -p client/src/styles

# Copy files
# - client/src/components/apple-ux/index.tsx
# - client/src/styles/apple-animations.css
```

### Step 2: Import CSS

Add to `client/src/index.css`:

```css
@import './styles/apple-animations.css';
```

### Step 3: Start Using

```tsx
import { 
  haptic, 
  ElevatedCard, 
  LoadingButton, 
  SuccessCheckmark,
  DepthSheet,
  Material 
} from "@/components/apple-ux";

// Haptic feedback
haptic("success"); // On task completion
haptic("selection"); // On tab change
haptic("error"); // On validation error

// Elevated cards
<ElevatedCard level={2} hover={true}>
  Card content
</ElevatedCard>

// Loading buttons
<LoadingButton loading={isSubmitting} success={didSucceed}>
  Submit
</LoadingButton>

// Depth sheets
<DepthSheet open={showSheet} onClose={() => setShowSheet(false)}>
  Sheet content
</DepthSheet>
```

---

## Component Reference

### Haptic Feedback

```tsx
import { haptic } from "@/components/apple-ux";

// Available patterns
haptic("light");      // 10ms - subtle tap
haptic("medium");     // 25ms - standard press
haptic("heavy");      // 50ms - strong press
haptic("success");    // double tap pattern
haptic("warning");    // triple pulse
haptic("error");      // strong double
haptic("selection");  // 8ms - tab change
```

### Elevated Cards

```tsx
import { ElevatedCard } from "@/components/apple-ux";

// Elevation levels 0-4
<ElevatedCard level={0}>Flat</ElevatedCard>
<ElevatedCard level={1}>Subtle shadow</ElevatedCard>
<ElevatedCard level={2}>Standard card</ElevatedCard>
<ElevatedCard level={3}>Floating element</ElevatedCard>
<ElevatedCard level={4}>Modal/sheet</ElevatedCard>

// With hover effect
<ElevatedCard level={2} hover={true}>
  Lifts on hover
</ElevatedCard>

// Clickable
<ElevatedCard level={2} onClick={() => {}}>
  Clickable card
</ElevatedCard>
```

### Materials (Frosted Glass)

```tsx
import { Material } from "@/components/apple-ux";

<Material type="regular">Standard blur</Material>
<Material type="thick">More opaque</Material>
<Material type="thin">More translucent</Material>
<Material type="ultrathin">Most translucent</Material>
<Material type="chrome">Navigation bar style</Material>
```

### Depth Sheet

```tsx
import { DepthSheet } from "@/components/apple-ux";

function MyComponent() {
  const [open, setOpen] = useState(false);
  
  return (
    <>
      <button onClick={() => setOpen(true)}>Open Sheet</button>
      
      <DepthSheet open={open} onClose={() => setOpen(false)}>
        {/* Background automatically scales and blurs */}
        <div className="p-5">
          Sheet content
        </div>
      </DepthSheet>
    </>
  );
}
```

### Loading Button

```tsx
import { LoadingButton } from "@/components/apple-ux";

function MyForm() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  const handleSubmit = async () => {
    setLoading(true);
    await submitForm();
    setSuccess(true);
    setLoading(false);
  };
  
  return (
    <LoadingButton 
      loading={loading} 
      success={success}
      onClick={handleSubmit}
    >
      Submit
    </LoadingButton>
  );
}
```

### Success Checkmark

```tsx
import { SuccessCheckmark, SuccessOverlay } from "@/components/apple-ux";

// Inline checkmark
<SuccessCheckmark size={48} onComplete={() => console.log("done")} />

// Full screen overlay
<SuccessOverlay 
  show={showSuccess} 
  message="Task Complete!" 
  onComplete={() => setShowSuccess(false)} 
/>
```

### Skeleton Loading

```tsx
import { AppleSkeleton, CardSkeleton } from "@/components/apple-ux";

// Basic skeleton
<AppleSkeleton className="h-4 w-32" />

// Full card skeleton
<CardSkeleton />
```

### Progress Indicators

```tsx
import { ProgressRing, IndeterminateProgress } from "@/components/apple-ux";

// Circular progress (0-100)
<ProgressRing progress={75} size={40} />

// Indeterminate bar
<IndeterminateProgress />
```

### Pressable Wrapper

```tsx
import { Pressable } from "@/components/apple-ux";

<Pressable onPress={() => {}} hapticFeedback="medium">
  <div>Adds press feedback to any element</div>
</Pressable>
```

---

## CSS Classes Reference

### Shadows
```css
.shadow-apple-sm   /* Subtle */
.shadow-apple-md   /* Standard */
.shadow-apple-lg   /* Elevated */
.shadow-apple-xl   /* Prominent */
.shadow-apple-float /* Floating/modal */
```

### Materials
```css
.material-regular
.material-thick
.material-thin
.material-ultrathin
```

### Animations
```css
.animate-shimmer          /* Loading shimmer */
.animate-bounce-in        /* Bouncy entrance */
.animate-fade-up          /* Fade + slide up */
.animate-scale-in-spring  /* Scale with spring */
.animate-shake            /* Error shake */
.animate-subtle-pulse     /* Attention pulse */
```

### Stagger Delays
```css
.stagger-1 through .stagger-8  /* 0.05s increments */
```

### Press States
```css
.press-feedback       /* Scale down on :active */
.card-press-feedback  /* Card-specific press */
.focus-ring          /* Visible focus state */
```

---

## Accessibility

This package includes:

- ✅ `prefers-reduced-motion` support - animations disabled when requested
- ✅ Focus indicators with `.focus-ring` class
- ✅ Proper ARIA attributes in components
- ✅ Haptics fall back gracefully on unsupported devices

---

## Files Included

```
apple-ux/
├── README.md                              # This file
├── client/
│   └── src/
│       ├── components/
│       │   └── apple-ux/
│       │       └── index.tsx              # All components
│       └── styles/
│           └── apple-animations.css       # CSS animations
└── IMPLEMENTATION_EXAMPLES.tsx            # Usage examples
```
