/**
 * PATCH: Add encryption to vault access items
 * 
 * Apply these changes to server/routes.ts for the access-items endpoints.
 */

// ============================================================
// STEP 1: Add import at top of routes.ts
// ============================================================

import { encryptVaultValue, decryptVaultValue, migrateToEncrypted } from "./services/vault-encryption";

// ============================================================
// STEP 2: Update POST /api/access-items to encrypt values
// ============================================================

app.post("/api/access-items", isAuthenticated, householdContext, async (req: any, res) => {
  try {
    const householdId = req.householdId!;
    const data = insertAccessItemSchema.parse(req.body);
    
    // Encrypt sensitive values before storage
    const encryptedValue = data.isSensitive 
      ? encryptVaultValue(data.value)
      : data.value;
    
    const accessItem = await storage.createAccessItem({
      ...data,
      value: encryptedValue,
      isEncrypted: data.isSensitive, // Mark as encrypted
      householdId,
    });
    
    // Return with decrypted value for immediate use (don't expose encrypted format)
    res.status(201).json({
      ...accessItem,
      value: data.isSensitive ? "[ENCRYPTED]" : data.value, // Don't return actual value in create response
    });
  } catch (error) {
    console.error("Error creating access item:", error);
    res.status(500).json({ message: "Failed to create access item" });
  }
});

// ============================================================
// STEP 3: Update PUT /api/access-items/:id to encrypt values
// ============================================================

app.put("/api/access-items/:id", isAuthenticated, householdContext, requirePermission("CAN_EDIT_VAULT"), async (req: any, res) => {
  try {
    const householdId = req.householdId!;
    const { id } = req.params;
    const data = req.body;
    
    // If value is being updated and item is sensitive, encrypt it
    if (data.value !== undefined) {
      const isSensitive = data.isSensitive ?? true; // Default to sensitive
      data.value = isSensitive 
        ? encryptVaultValue(data.value)
        : data.value;
      data.isEncrypted = isSensitive;
    }
    
    const updated = await storage.updateAccessItem(householdId, id, data);
    
    if (!updated) {
      return res.status(404).json({ message: "Access item not found" });
    }
    
    // Return without sensitive values
    res.json({
      ...updated,
      value: updated.isSensitive ? "[ENCRYPTED]" : updated.value,
    });
  } catch (error) {
    console.error("Error updating access item:", error);
    res.status(500).json({ message: "Failed to update access item" });
  }
});

// ============================================================
// STEP 4: Update GET /api/access-items to return masked values
// ============================================================

app.get("/api/access-items", isAuthenticated, householdContext, async (req: any, res) => {
  try {
    const householdId = req.householdId!;
    const items = await storage.getAccessItems(householdId);
    
    // Mask sensitive values in list view
    const maskedItems = items.map(item => ({
      ...item,
      value: item.isSensitive ? "[ENCRYPTED]" : item.value,
    }));
    
    res.json(maskedItems);
  } catch (error) {
    console.error("Error fetching access items:", error);
    res.status(500).json({ message: "Failed to fetch access items" });
  }
});

// ============================================================
// STEP 5: Update POST /api/access-items/:id/reveal to decrypt
// ============================================================

app.post("/api/access-items/:id/reveal", isAuthenticated, householdContext, requirePermission("CAN_VIEW_VAULT"), async (req: any, res) => {
  try {
    const householdId = req.householdId!;
    const userId = req.user.claims.sub;
    const { id } = req.params;
    
    const item = await storage.getAccessItem(householdId, id);
    
    if (!item) {
      return res.status(404).json({ message: "Access item not found" });
    }
    
    // Log the reveal attempt for audit
    await logAuditEvent({
      householdId,
      userId,
      action: "VAULT_ITEM_REVEALED",
      entityType: "VAULT",
      entityId: id,
      afterJson: JSON.stringify({ itemTitle: item.title }),
    });
    
    // Decrypt the value if encrypted
    const decryptedValue = item.isEncrypted 
      ? decryptVaultValue(item.value)
      : item.value;
    
    res.json({
      ...item,
      value: decryptedValue,
    });
  } catch (error) {
    console.error("Error revealing access item:", error);
    res.status(500).json({ message: "Failed to reveal access item" });
  }
});

// ============================================================
// STEP 6: Migration endpoint to encrypt existing unencrypted items
// ============================================================

app.post("/api/admin/migrate-vault-encryption", isAuthenticated, householdContext, requirePermission("CAN_MANAGE_SETTINGS"), async (req: any, res) => {
  try {
    const householdId = req.householdId!;
    const items = await storage.getAccessItems(householdId);
    
    let migrated = 0;
    
    for (const item of items) {
      if (item.isSensitive && !item.isEncrypted) {
        const encryptedValue = encryptVaultValue(item.value);
        await storage.updateAccessItem(householdId, item.id, {
          value: encryptedValue,
          isEncrypted: true,
        });
        migrated++;
      }
    }
    
    res.json({ 
      success: true, 
      message: `Migrated ${migrated} items to encrypted storage`,
      totalItems: items.length,
      migratedItems: migrated,
    });
  } catch (error) {
    console.error("Error migrating vault encryption:", error);
    res.status(500).json({ message: "Failed to migrate vault encryption" });
  }
});
