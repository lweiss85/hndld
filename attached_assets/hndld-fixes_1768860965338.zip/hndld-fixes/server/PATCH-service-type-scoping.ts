/**
 * PATCH: Add Service Type Scoping to Routes
 * 
 * This patch shows how to add service type filtering to list endpoints.
 * Apply these changes to server/routes.ts
 */

// ============================================================
// STEP 1: Add imports at top of routes.ts
// ============================================================

import { serviceScopeMiddleware, getServiceTypeFilter, ServiceScopedRequest } from "./middleware/serviceScope";

// ============================================================
// STEP 2: Add middleware to the chain (after householdContext)
// ============================================================

// In your route setup, add serviceScopeMiddleware after householdContext:
// 
// BEFORE:
// app.get("/api/tasks", isAuthenticated, householdContext, async (req: any, res) => {
//
// AFTER:
// app.get("/api/tasks", isAuthenticated, householdContext, serviceScopeMiddleware, async (req: ServiceScopedRequest, res) => {

// ============================================================
// STEP 3: Update list endpoints to filter by service type
// ============================================================

// --- TASKS ---
// Replace the GET /api/tasks handler:

app.get("/api/tasks", isAuthenticated, householdContext, serviceScopeMiddleware, async (req: ServiceScopedRequest, res) => {
  try {
    const householdId = req.householdId!;
    const serviceTypeFilter = getServiceTypeFilter(req);
    
    let tasksQuery = db.select().from(tasks)
      .where(eq(tasks.householdId, householdId));
    
    // Apply service type filter if user doesn't have access to all types
    if (serviceTypeFilter) {
      tasksQuery = tasksQuery.where(
        and(
          eq(tasks.householdId, householdId),
          eq(tasks.serviceType, serviceTypeFilter)
        )
      );
    }
    
    const allTasks = await tasksQuery.orderBy(desc(tasks.createdAt));
    res.json(allTasks);
  } catch (error) {
    console.error("Error fetching tasks:", error);
    res.status(500).json({ message: "Failed to fetch tasks" });
  }
});

// --- APPROVALS ---
// Replace the GET /api/approvals handler:

app.get("/api/approvals", isAuthenticated, householdContext, serviceScopeMiddleware, async (req: ServiceScopedRequest, res) => {
  try {
    const householdId = req.householdId!;
    const serviceTypeFilter = getServiceTypeFilter(req);
    
    let query = db.select().from(approvals)
      .where(eq(approvals.householdId, householdId));
    
    if (serviceTypeFilter) {
      query = query.where(
        and(
          eq(approvals.householdId, householdId),
          eq(approvals.serviceType, serviceTypeFilter)
        )
      );
    }
    
    const allApprovals = await query.orderBy(desc(approvals.createdAt));
    res.json(allApprovals);
  } catch (error) {
    console.error("Error fetching approvals:", error);
    res.status(500).json({ message: "Failed to fetch approvals" });
  }
});

// --- UPDATES ---
// Replace the GET /api/updates handler:

app.get("/api/updates", isAuthenticated, householdContext, serviceScopeMiddleware, async (req: ServiceScopedRequest, res) => {
  try {
    const householdId = req.householdId!;
    const serviceTypeFilter = getServiceTypeFilter(req);
    
    let query = db.select().from(updates)
      .where(eq(updates.householdId, householdId));
    
    if (serviceTypeFilter) {
      query = query.where(
        and(
          eq(updates.householdId, householdId),
          eq(updates.serviceType, serviceTypeFilter)
        )
      );
    }
    
    const allUpdates = await query.orderBy(desc(updates.createdAt));
    
    // ... rest of handler (reactions fetching, etc.)
    res.json(allUpdates);
  } catch (error) {
    console.error("Error fetching updates:", error);
    res.status(500).json({ message: "Failed to fetch updates" });
  }
});

// --- SPENDING ---
// Replace the GET /api/spending handler:

app.get("/api/spending", isAuthenticated, householdContext, serviceScopeMiddleware, async (req: ServiceScopedRequest, res) => {
  try {
    const householdId = req.householdId!;
    const serviceTypeFilter = getServiceTypeFilter(req);
    
    let query = db.select().from(spendingItems)
      .where(eq(spendingItems.householdId, householdId));
    
    if (serviceTypeFilter) {
      query = query.where(
        and(
          eq(spendingItems.householdId, householdId),
          eq(spendingItems.serviceType, serviceTypeFilter)
        )
      );
    }
    
    const spending = await query.orderBy(desc(spendingItems.date));
    res.json(spending);
  } catch (error) {
    console.error("Error fetching spending:", error);
    res.status(500).json({ message: "Failed to fetch spending" });
  }
});

// ============================================================
// STEP 4: Ensure new records get proper serviceType
// ============================================================

// When creating tasks, approvals, updates, spending - use req.serviceType:

app.post("/api/tasks", isAuthenticated, householdContext, serviceScopeMiddleware, requirePermission("CAN_EDIT_TASKS"), async (req: ServiceScopedRequest, res) => {
  try {
    const householdId = req.householdId!;
    const userId = req.user.claims.sub;
    
    // Use the service type from request body, or default to user's primary service type
    const serviceType = req.body.serviceType || req.serviceType || "PA";
    
    // Validate user has access to this service type
    if (!req.serviceTypes?.includes(serviceType)) {
      return res.status(403).json({ error: `You don't have access to ${serviceType} service` });
    }
    
    const task = await storage.createTask({
      ...req.body,
      householdId,
      createdBy: userId,
      serviceType, // Explicitly set service type
    });
    
    res.status(201).json(task);
  } catch (error) {
    console.error("Error creating task:", error);
    res.status(500).json({ message: "Failed to create task" });
  }
});
