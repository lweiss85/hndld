/**
 * Logger with PII Sanitization
 * 
 * Automatically redacts sensitive fields from log output.
 * 
 * Replace: server/lib/logger.ts
 */

import winston from "winston";

const logLevel = process.env.LOG_LEVEL || "info";
const isDevelopment = process.env.NODE_ENV !== "production";

// Fields that should be redacted from logs
const SENSITIVE_FIELDS = new Set([
  // Auth & Security
  "password",
  "pin",
  "pinHash",
  "token",
  "accessToken",
  "access_token",
  "refreshToken",
  "refresh_token",
  "secret",
  "apiKey",
  "api_key",
  "sessionSecret",
  "session_secret",
  
  // Personal Info
  "ssn",
  "socialSecurityNumber",
  "social_security_number",
  "creditCard",
  "credit_card",
  "cardNumber",
  "card_number",
  "cvv",
  "cvc",
  
  // Vault items
  "value", // Access item values
  "wifiPassword",
  "wifi_password",
  "alarmCode",
  "alarm_code",
  "gateCode",
  "gate_code",
  
  // OAuth
  "accessTokenEncrypted",
  "access_token_encrypted",
  "refreshTokenEncrypted",
  "refresh_token_encrypted",
  
  // Payment
  "stripeCustomerId",
  "stripe_customer_id",
  "venmoUsername",
  "venmo_username",
  "zelleRecipient",
  "zelle_recipient",
  "cashAppCashtag",
  "cash_app_cashtag",
  "paypalMeHandle",
  "paypal_me_handle",
]);

// Patterns to detect sensitive data that might have dynamic keys
const SENSITIVE_PATTERNS = [
  /password/i,
  /secret/i,
  /token/i,
  /apikey/i,
  /api_key/i,
  /auth/i,
  /credential/i,
  /private/i,
];

/**
 * Recursively sanitize an object, redacting sensitive fields
 */
function sanitize(obj: any, seen = new WeakSet()): any {
  if (obj === null || obj === undefined) {
    return obj;
  }

  // Handle circular references
  if (typeof obj === "object") {
    if (seen.has(obj)) {
      return "[Circular]";
    }
    seen.add(obj);
  }

  // Handle arrays
  if (Array.isArray(obj)) {
    return obj.map(item => sanitize(item, seen));
  }

  // Handle objects
  if (typeof obj === "object") {
    const sanitized: Record<string, any> = {};
    
    for (const [key, value] of Object.entries(obj)) {
      // Check if key is sensitive
      const isSensitive = 
        SENSITIVE_FIELDS.has(key) ||
        SENSITIVE_FIELDS.has(key.toLowerCase()) ||
        SENSITIVE_PATTERNS.some(pattern => pattern.test(key));
      
      if (isSensitive) {
        sanitized[key] = "[REDACTED]";
      } else if (typeof value === "object" && value !== null) {
        sanitized[key] = sanitize(value, seen);
      } else {
        sanitized[key] = value;
      }
    }
    
    return sanitized;
  }

  return obj;
}

/**
 * Winston format that sanitizes sensitive data
 */
const sanitizeFormat = winston.format((info) => {
  // Sanitize the main message if it's an object
  if (typeof info.message === "object") {
    info.message = sanitize(info.message);
  }
  
  // Sanitize metadata
  const { level, message, timestamp, ...meta } = info;
  const sanitizedMeta = sanitize(meta);
  
  return {
    level,
    message,
    timestamp,
    ...sanitizedMeta,
  };
});

const logger = winston.createLogger({
  level: logLevel,
  format: winston.format.combine(
    winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
    winston.format.errors({ stack: true }),
    winston.format.splat(),
    sanitizeFormat(), // Apply sanitization
    isDevelopment
      ? winston.format.combine(
          winston.format.colorize(),
          winston.format.printf(({ timestamp, level, message, ...meta }) => {
            const metaStr = Object.keys(meta).length ? JSON.stringify(meta, null, 2) : "";
            return `${timestamp} [${level}] ${message} ${metaStr}`;
          })
        )
      : winston.format.json()
  ),
  transports: [
    new winston.transports.Console({
      stderrLevels: ["error"],
    }),
  ],
});

// Export sanitize function for use in other places
export { sanitize };

export default logger;
