# hndld Security & Bug Fixes

This package contains fixes for critical issues identified in the hndld codebase.

## Quick Start

1. Copy the entire `hndld-fixes` folder into your project root
2. Follow the instructions below to apply each fix

---

## Fix Summary

| # | Issue | Severity | Type |
|---|-------|----------|------|
| 1 | XSS in invoice HTML | 🔴 Critical | Security |
| 2 | HTML nesting in bottom-nav | 🟠 High | Accessibility |
| 3 | /today 404 link | 🟡 Medium | Bug |
| 4 | No service type scoping | 🟠 High | Security |
| 5 | Invoice file not written | 🟡 Medium | Bug |
| 6 | Duplicate Stripe invoices | 🟡 Medium | Data |
| 7 | Vault items plaintext | 🔴 Critical | Security |
| 8 | Session secure flag | 🟡 Medium | Bug |
| 9 | PII in logs | 🟠 High | Security |
| 10 | Bottom nav overflow | 🟢 Low | UX |

---

## Detailed Instructions

### Fix 1: XSS in Invoice Generation (CRITICAL)

**Files to add:**
```
server/lib/escape-html.ts (new file)
```

**Files to modify:**
- `server/routes.ts` - Replace the `/api/invoices/send` handler

**Steps:**
1. Copy `server/lib/escape-html.ts` to your project
2. Add import at top of `routes.ts`:
   ```typescript
   import { escapeHtml } from "./lib/escape-html";
   ```
3. Replace the `/api/invoices/send` handler (around line 1679) with the code in `PATCH-invoice-generation.ts`

---

### Fix 2: Bottom Nav HTML Nesting

**Files to replace:**
```
client/src/components/layout/bottom-nav.tsx
```

**Steps:**
1. Replace `client/src/components/layout/bottom-nav.tsx` with the fixed version

**What changed:**
- Removed `<button>` inside `<Link>` (invalid HTML)
- Now uses `useLocation()` hook with `onClick` for navigation
- Added proper ARIA attributes for accessibility
- Added `overflow-x-auto` for horizontal scrolling support

---

### Fix 3: /today 404 Link

**Files to modify:**
- `client/src/pages/payment-profile.tsx`

**Steps:**
1. Find line 176: `<Link href="/today">`
2. Change to: `<Link href="/">`

Or for better UX, replace the Link with a back button:
```tsx
<Button 
  variant="ghost" 
  size="icon" 
  onClick={() => window.history.back()}
>
  <ArrowLeft className="w-5 h-5" />
</Button>
```

---

### Fix 4: Service Type Scoping

**Files to add:**
```
server/middleware/serviceScope.ts (new file)
```

**Files to modify:**
- `server/routes.ts` - Add middleware and filtering

**Steps:**
1. Copy `server/middleware/serviceScope.ts` to your project
2. Follow instructions in `PATCH-service-type-scoping.ts` to update routes

**What this does:**
- CLEANING users only see CLEANING tasks/approvals/updates/spending
- PA users see PA data
- Users with both memberships see both

---

### Fix 5: Invoice File Writing

This is fixed as part of Fix 1 (see PATCH-invoice-generation.ts).

The invoice HTML is now actually written to storage using:
```typescript
await storageProvider.upload(storagePath, invoiceBuffer, 'text/html');
```

---

### Fix 6: Stripe Invoice Duplicates

**Run this SQL migration:**
```sql
-- From migrations/001_unique_stripe_invoice_id.sql

-- Remove duplicates first
WITH duplicates AS (
  SELECT id, 
         ROW_NUMBER() OVER (
           PARTITION BY stripe_invoice_id 
           ORDER BY created_at DESC
         ) as rn
  FROM invoices 
  WHERE stripe_invoice_id IS NOT NULL
)
DELETE FROM invoices 
WHERE id IN (SELECT id FROM duplicates WHERE rn > 1);

-- Add unique constraint
ALTER TABLE invoices 
ADD CONSTRAINT invoices_stripe_invoice_id_unique 
UNIQUE (stripe_invoice_id);
```

---

### Fix 7: Vault Encryption (CRITICAL)

**Files to add:**
```
server/services/vault-encryption.ts (new file)
```

**Files to modify:**
- `server/routes.ts` - Update access-items endpoints
- `.env` - Add VAULT_ENCRYPTION_KEY

**Steps:**
1. Copy `server/services/vault-encryption.ts` to your project
2. Add to your `.env`:
   ```
   # Generate with: node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   VAULT_ENCRYPTION_KEY=your-64-char-hex-key
   ```
3. Follow instructions in `PATCH-vault-encryption.ts` to update routes
4. Run the migration endpoint to encrypt existing items:
   ```
   POST /api/admin/migrate-vault-encryption
   ```

---

### Fix 8: Session Secure Flag

**Files to replace:**
```
server/replit_integrations/auth/replitAuth.ts
```

**Steps:**
1. Replace with the fixed version from `hndld-fixes`

**What changed:**
- `secure: true` → `secure: isProduction || isReplit`
- Added `sameSite: "lax"` for OAuth compatibility

---

### Fix 9: PII in Logs

**Files to replace:**
```
server/lib/logger.ts
```

**Steps:**
1. Replace with the fixed version from `hndld-fixes`

**What changed:**
- Adds automatic redaction of sensitive fields (passwords, tokens, PII)
- Handles nested objects and arrays
- Detects sensitive fields by name patterns

---

### Fix 10: Bottom Nav Overflow

**Files to modify:**
- `client/src/index.css`

**Steps:**
1. Add the CSS from `PATCH-index.css` to your `index.css`:
   ```css
   .scrollbar-hide::-webkit-scrollbar {
     display: none;
   }
   .scrollbar-hide {
     -ms-overflow-style: none;
     scrollbar-width: none;
   }
   ```

The fixed `bottom-nav.tsx` already uses `overflow-x-auto scrollbar-hide`.

---

## Environment Variables

Make sure your `.env` includes all required variables. See `.env.example` for the complete list.

**New required variables:**
- `VAULT_ENCRYPTION_KEY` - 64-char hex string for vault encryption

---

## Testing

After applying fixes, test:

1. **Invoice XSS**: Create an invoice with `<script>alert('xss')</script>` in the title
2. **Bottom nav**: Check it works on mobile and screen readers
3. **Service scoping**: Log in as CLEANING user, verify PA data is hidden
4. **Vault**: Create an access item, check database for encrypted value
5. **Session**: Test login works in both dev and production

---

## Questions?

These fixes address the most critical issues found in the code review.
For additional improvements (splitting routes.ts, adding tests, etc.),
those are larger refactoring efforts that should be planned separately.
