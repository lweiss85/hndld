/**
 * PATCH: Fix /today 404 in payment-profile.tsx
 * 
 * Location: client/src/pages/payment-profile.tsx
 * Line: 176
 * 
 * PROBLEM:
 * The back button links to "/today" which doesn't exist as a route.
 * - Assistants see Today page at "/" 
 * - Clients see ThisWeek page at "/"
 * - Neither role has a "/today" route
 * 
 * SOLUTION:
 * Change the link from "/today" to "/" (home route for both roles)
 */

// FIND THIS (around line 176):
<Link href="/today">
  <Button variant="ghost" size="icon" data-testid="button-back">
    <ArrowLeft className="w-5 h-5" />
  </Button>
</Link>

// REPLACE WITH:
<Link href="/">
  <Button variant="ghost" size="icon" data-testid="button-back">
    <ArrowLeft className="w-5 h-5" />
  </Button>
</Link>

/**
 * ALTERNATIVE: Use browser history for proper back navigation
 * This is better UX as it returns to wherever the user came from:
 */

// At top of file, add:
// import { useLocation } from "wouter";

// Replace the Link with:
<Button 
  variant="ghost" 
  size="icon" 
  data-testid="button-back"
  onClick={() => window.history.back()}
>
  <ArrowLeft className="w-5 h-5" />
</Button>
