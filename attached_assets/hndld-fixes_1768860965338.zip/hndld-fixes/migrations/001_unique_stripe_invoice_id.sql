/**
 * Migration: Add unique constraint to stripeInvoiceId
 * 
 * This prevents duplicate invoice records from webhook retries.
 * 
 * To apply:
 * 1. Save this file to your migrations folder
 * 2. Run: npx drizzle-kit push
 * 
 * Or manually run the SQL in your database.
 */

-- SQL Migration
-- Run this in your PostgreSQL database:

-- First, check for and remove any duplicates
WITH duplicates AS (
  SELECT id, 
         ROW_NUMBER() OVER (
           PARTITION BY stripe_invoice_id 
           ORDER BY created_at DESC
         ) as rn
  FROM invoices 
  WHERE stripe_invoice_id IS NOT NULL
)
DELETE FROM invoices 
WHERE id IN (SELECT id FROM duplicates WHERE rn > 1);

-- Now add the unique constraint
ALTER TABLE invoices 
ADD CONSTRAINT invoices_stripe_invoice_id_unique 
UNIQUE (stripe_invoice_id);

-- Also add index for faster lookups
CREATE INDEX IF NOT EXISTS idx_invoices_stripe_invoice_id 
ON invoices (stripe_invoice_id) 
WHERE stripe_invoice_id IS NOT NULL;
